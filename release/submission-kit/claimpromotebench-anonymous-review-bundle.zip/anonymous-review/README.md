# ClaimPromoteBench anonymous reviewer bundle

This focused bundle contains the material needed to replay the paper: the public controlled
benchmark, executable and Lean fixtures, the reviewer-release r6 data, the pair-balanced public
challenge, the SLSA-derived evidence study, three pinned open-weight local replications, and the
20-cell Ox Alpha minimum-route smoke replay. It
contains no Git history, author metadata, public repository link, private construction seed,
human-subject record, or public workflow identifier.

## Reproduce the review environment

```bash
python -m pip install --require-hashes -r requirements-review.lock
python -m pip install --no-deps -e .
python scripts/run_review_checks.py
```

The default command uses the staged files to validate the public alpha benchmark, verify all 20
controlled-pair contracts, run shortcut, invariance, executable, empirical-evidence,
naturalistic-freeze, and selected pytest checks, then build and check the Lean fixtures. It fails
if `lake` is missing.
Use `--python-only` for an explicitly partial replay when Lean is unavailable.

The evidence directory retains the r6 300-item hidden realization, frozen baseline, projected
records, and analysis; the 180-item public challenge; the hosted 120-item SLSA-field study; three
local 120-item software-policy studies; and the 20-cell Ox route replay. Paper-facing records retain
the action needed for metric replay, parse and failure classes, and every scheduled denominator
while omitting raw response text and free-form errors. Provider account and response identifiers,
credentials, author provenance, and hidden reasoning are excluded.

## Scope limitation

The private deterministic-construction seed remains excluded because the released dataset bytes,
prompt packet, labels, records, and commitments suffice for result recomputation. The r6
construction manifest remains byte-frozen. Its stale `CFM_R5` namespace label and
three construction-time `PENDING` values are corrected by a bound overlay; all released r6 item
and pair IDs use the `v1-test-cfo-*` namespace. The original manifest is not rewritten because its
digest is bound by C1 and C2. Provider hidden-thinking blocks are excluded from the r6 derivative,
and a redaction receipt records the post-C2 publication boundary and score-equivalence check.

The challenge is pair-balanced and non-ALLOW-balanced, with gold support 90/30/30/30; it is not a
four-class-balanced hidden test. Its service stacks differ, so their outcomes do not form a causal
model ablation. Every unusable r6 or challenge response remains in the registered denominator. The
top-level manifest records the generated tree's actual file count.

The SLSA-derived study instantiates a second authored policy ontology. The local policy-switch
study holds evidence and states fixed while changing only the applicable published profile. SLSA
and in-toto ground the evidence vocabulary; all transition rules, profiles, and labels remain
author-defined. These studies are not standards certification, naturalistic deployment estimates,
or between-route causal comparisons. Every scheduled failure in a retained study remains in the
end-to-end denominator. Recomputable receipts distinguish coverage of all 12 authored profile
differences from behavioral coverage: the rule-stratified suite covers 6/10 reachable directed
non-self action transitions, while the transition graph covers 10/10 and certifies two impossible
directions.

Two frozen hosted policy-switch executions, one hosted transition-graph execution, and one 40-cell
minimum-suite execution exhausted a shared subscription quota. All four are excluded in full, and
the bundle retains only redacted exclusion receipts. No excluded hosted row, item record, or
conditional hosted metric enters the paper or reviewer evidence.

The later Ox Alpha replay is separate from that excluded 40-cell execution. Its route and minimum
suite were selected after earlier results were known, then the 20-item schedule, zero-retry rule,
failure denominator, and strict gate were committed before its first call. The stealth label does
not identify a model family. This time-stamped replay supports only route-level smoke-test claims.

Two open-weight model families were selected and revision-pinned before benchmark inference, then
run locally on all three software-policy datasets with greedy decoding and zero retries. Exact model
revisions, snapshot file digests, qualification receipts, and every terminal outcome are included;
weights are downloaded from their upstream repositories and are not redistributed in this bundle.

The frozen naturalistic-candidate pool contains 12 source pointers. Source-level review created
zero benchmark cases and made zero model calls because the records lacked the time-stamped
execution, dependency, runtime, provenance, and licensing evidence required for a defensible
author-policy mapping. This is an inclusion decision, not a naturalistic evaluation result; no
human annotators, human gold labels, or agreement statistic are claimed.

Post-gate correctness applies the same fixed policy as the benchmark oracle. It must not be
interpreted as model learning or independent prediction accuracy.
