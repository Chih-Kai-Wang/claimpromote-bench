# ClaimPromoteBench anonymous reviewer bundle

This bundle reproduces the paper's synthetic policy-transition benchmarks and model-service
regression studies. It contains exact Gatekeeper, Trivy, and Cosign source revisions; the frozen
Gatekeeper route repetitions; the r6 and balanced-challenge records; the authored SLSA migration
suite; pinned local replications; and a content-free dual-endpoint audit.

## Reproduce the review environment

Use Python 3.11 or newer.

```bash
python -m pip install --require-hashes -r requirements-review.lock
python -m pip install --no-deps -e .
python scripts/run_review_checks.py
```

The default command validates source bindings, controlled-pair contracts, benchmark invariants,
empirical aggregates, privacy receipts, selected tests, and Lean fixtures. `--python-only` runs the
Python replay when Lean is unavailable.

## Evidence map

- `v2/upstream-policy-revisions-v1/`, `v2/trivy-policy-revision-v1/`, and
  `v2/sigstore-policy-verifier-revision-v1/` bind upstream source, tests, licenses, authored finite
  contexts, and deterministic validation receipts.
- `evidence/upstream-policy-route-repetition/` retains all 144 scheduled terminal classes and the
  six sanitized 24-item result files used for the three-repetition analysis.
- `evidence/fresh-confirmatory/` and `evidence/balanced-public-challenge/` reproduce the r6 coverage
  addendum and public challenge.
- `evidence/slsa-portability/` and `evidence/local-model-replications/` reproduce the authored
  migration and fixed-policy studies.
- `evidence/dual-endpoint-audit/` provides 1,320 content-free item records that recompute the strict
  action and contract-action endpoints.

## Release boundary

Every scheduled service, syntax, schema, and semantic failure stays in its registered end-to-end
denominator. Paper-facing records retain actions, terminal classes, and correctness fields needed
for metric replay. The release omits raw response text, free-form transport errors, provider
response identifiers, account identifiers, credentials, hidden reasoning, Git history, and author
provenance. Each manifest derives its file count from the generated tree.

The private construction seed is unnecessary for score recomputation and remains outside the
bundle. A bound overlay corrects stale r6 construction metadata while preserving the byte-frozen
manifest. The naturalistic-candidate audit reviewed 12 source pointers, admitted zero cases, and
made zero model calls under the predeclared provenance threshold.

The central model IDs share one provider/API and adapter configuration; provider-side serving
internals remain opaque. Cross-route values are descriptive. The challenge was author-created and
publicly frozen before calls, and the SLSA labels are author-defined policy mappings. The
deterministic executor is the policy definition's ceiling; the Naive Bayes model is a deliberately
weak sanity control.
