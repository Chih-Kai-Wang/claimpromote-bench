# ClaimPromoteBench anonymous reviewer bundle

This focused bundle contains the material needed to replay the paper: the public controlled
benchmark, executable and Lean fixtures, the reviewer-release r6 data, the pair-balanced public
challenge, and item-level scoring records. It
contains no Git history, author metadata, public repository link, private construction seed,
human-subject record, or public workflow identifier.

## Reproduce the review environment

```bash
python -m pip install --require-hashes -r requirements-review.lock
python -m pip install --no-deps -e .
python scripts/run_review_checks.py
```

The default command uses the staged files to validate the public alpha benchmark, verify all 20
controlled-pair contracts, run shortcut, invariance, executable, empirical-evidence,
naturalistic-freeze, and selected pytest checks, then build and check the Lean fixtures. It fails
if `lake` is missing.
Use `--python-only` for an explicitly partial replay when Lean is unavailable.

The evidence directory retains the r6 300-item hidden realization, frozen baseline, projected
records, and analysis, together with the 180-item public challenge and both service routes. The
balanced-challenge records retain the model's final JSON text and sanitized error text for parser
audit. Provider account and response identifiers, credentials, author provenance, and hidden
reasoning are excluded.

## Scope limitation

The private deterministic-construction seed remains excluded because the released dataset bytes,
prompt packet, labels, records, and commitments suffice for result recomputation. The r6
construction manifest remains byte-frozen. Its stale `CFM_R5` namespace label and
three construction-time `PENDING` values are corrected by a bound overlay; all released r6 item
and pair IDs use the `v1-test-cfo-*` namespace. The original manifest is not rewritten because its
digest is bound by C1 and C2. Provider hidden-thinking blocks are excluded from the r6 derivative,
and a redaction receipt records the post-C2 publication boundary and score-equivalence check.

The challenge is pair-balanced and non-ALLOW-balanced, with gold support 90/30/30/30; it is not a
four-class-balanced hidden test. Its service stacks differ, so their outcomes do not form a causal
model ablation. Every unusable r6 or challenge response remains in the registered denominator. The
top-level manifest records the generated tree's actual file count.

The frozen naturalistic-candidate pool contains 12 source pointers. Source-level review created
zero benchmark cases and made zero model calls because the records lacked the time-stamped
execution, dependency, runtime, provenance, and licensing evidence required for a defensible
author-policy mapping. This is an inclusion decision, not a naturalistic evaluation result; no
human annotators, human gold labels, or agreement statistic are claimed.

Post-gate correctness applies the same fixed policy as the benchmark oracle. It must not be
interpreted as model learning or independent prediction accuracy.
