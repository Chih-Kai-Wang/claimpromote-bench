# ClaimPromoteBench anonymous reviewer bundle

This bundle provides deterministic source and score replay for the paper's policy-transition
benchmarks and retained model-service records. It never issues hosted calls. The evidence includes
exact Gatekeeper, Trivy, Cosign, and Agent Governance Toolkit source revisions; agentgateway test
evidence; six sanitized Gatekeeper route repetitions; the imbalanced evidence-state suite and
balanced challenge; two public `AGENTS.md` revisions; a factor-complete route study; the
SLSA-inspired migration and local replications; and a privacy-filtered endpoint reanalysis.

## Reproduce the review environment

Use Python 3.11 or newer.

```bash
python -m pip install --require-hashes -r requirements-review.lock
python -m pip install --no-deps -e .
python scripts/run_review_checks.py
```

The default command validates source bindings, controlled-pair contracts, benchmark invariants,
empirical aggregates, privacy receipts, selected tests, and Lean fixtures. `--python-only` runs the
Python replay when Lean is unavailable.

## Evidence map

- `v2/upstream-policy-revisions-v1/`, `v2/trivy-policy-revision-v1/`, and
  `v2/sigstore-policy-verifier-revision-v1/` bind upstream source, tests, licenses, constructed
  finite contexts, and deterministic validation receipts.
- `v2/agent-governance-policy-interface-revision-v1/` reproduces the parent/fixed Rego verdict gap;
  `v2/external-evidence-audit-v1/` binds the source-screen registry and agentgateway test evidence.
- `evidence/upstream-policy-route-repetition/` retains all 144 scheduled terminal classes and the
  six sanitized 24-item result files used for the three-repetition analysis.
- `evidence/fresh-confirmatory/` and `evidence/balanced-public-challenge/` reproduce the imbalanced
  suite's coverage addendum and balanced challenge.
- `evidence/external-agent-policy/` binds two independently authored public `AGENTS.md` histories,
  ten author-mapped pairs, and 480 terminal route records. Public upstream commits remain visible;
  the private study commit is withheld.
- `evidence/factor-complete-route/` retains 630 terminal records for one fixed pair per registered
  factor across seven routes and three repetitions.
- `evidence/slsa-portability/` and `evidence/local-model-replications/` reproduce the SLSA-inspired
  migration and fixed-policy studies.
- `evidence/dual-endpoint-audit/` provides 1,320 content-free item records that recompute
  raw-strict, registered-parser, and full-contract endpoints with parser provenance. The included
  endpoint parser source makes the distinction inspectable without releasing response text.

## Release boundary

Every scheduled service, syntax, schema, and semantic failure stays in its registered end-to-end
denominator. Paper-facing records retain actions, terminal classes, and correctness fields needed
for metric replay. The release omits raw response text, free-form transport errors, provider
response identifiers, account identifiers, credentials, hidden reasoning, Git history, and author
provenance. Each manifest derives its file count from the generated tree.

The private construction seed is unnecessary for score recomputation and remains outside the
bundle. A versioned metadata overlay supplies current terminology while preserving the source-bound
manifest. The source screen covered 465 public repository seeds, inspected 11 candidates, and
retained two executable boundary-fault cases with zero model calls. The separate model-facing study
uses naturally occurring prose-policy revisions and author-defined action mappings.

Exploratory outputs that contribute no manuscript metric are excluded. The central model IDs share
one provider/API and adapter configuration, with opaque provider-side serving internals; cross-route
values are descriptive. The balanced challenge was fixed before inference and measures robustness
on known cases. SLSA labels are author policy mappings, the deterministic executor defines the
policy ceiling, and Naive Bayes supplies a weak shortcut control.
