# ClaimPromoteBench anonymous reviewer bundle

This bundle contains the public controlled benchmark, executable fixtures, public Lean package,
selected validation code, the reviewer-release hidden dataset, item-level empirical records,
and compact paper-result summaries. It contains no Git history,
author metadata, public repository link, private construction seed, human-subject record, or public
workflow/provenance identifier.

## What can be checked

```bash
python -m pip install -e ".[test]"
python scripts/run_review_checks.py
```

The checks rebuild and validate the public alpha benchmark, verify all 20 controlled-pair contracts, run shortcut/invariance/executable
checks, validate the compact paper-result summaries, verify the frozen naturalistic-candidate
pool and its pre-model-call zero-case decision, and run selected v2 tests. The evidence
directory retains the available v1
source and normalized item records, all four public-interface pilot runs, the public-development
follow-up records, and all 14 executed capable-extension pilot attempts plus both fresh full
passes. It also contains the r6 preregistered 300-item fresh confirmatory dataset, projected C2
records, frozen baseline, and complete scientific analysis. The balanced public challenge adds
90 pairs / 180 items, both one-pass service runs, full confusion matrices, conditional and
end-to-end metrics, and a privacy receipt. Public repository identities are replaced by anonymous
role labels;
empirical prompts, responses, parser outcomes, gold labels, and model identities are retained.

For the public formal artifacts:

```bash
cd data/alpha
lake build
lake env leanchecker ClaimPromoteFormal
cd ../..
python -m claimpromotebench.formal   --dataset data/alpha   --fixtures fixtures/formal/cases.json   --out work/formal-fixtures.json
```

## Scope limitation

Original free-form text was not retained for v1 records classified as format failures, so no later
bundle can recover it. The included source and normalized records preserve every field that was
archived. The capable hidden extension and public-development follow-up retain their item-level raw
response text. The private deterministic-construction seed remains excluded because the released
dataset bytes, prompt packet, labels, records, and commitments suffice for result recomputation.
The public manifest's `model_experiments: PENDING` value is its pre-inference freeze status; the
result files carry the completed study states.

The r6 construction manifest likewise remains byte-frozen. Its stale `CFM_R5` namespace label and
three construction-time `PENDING` values are corrected by a bound overlay; all released r6 item
and pair IDs use the `v1-test-cfo-*` namespace. The original manifest is not rewritten because its
digest is bound by C1 and C2. Provider hidden-thinking blocks are excluded from the r6 derivative,
and a redaction receipt records the post-C2 publication boundary and score-equivalence check.

The balanced challenge is public precommitted robustness evidence, not a hidden-test estimate.
Its service stacks differ, so their outcomes are descriptive rather than a causal model ablation.
All unusable responses remain incorrect. Provider response identifiers and hidden-reasoning
content are excluded from the bundle. The top-level manifest records the generated tree's actual
file count, which verification recomputes from disk.

The frozen naturalistic-candidate pool contains 12 source pointers. Source-level review created
zero benchmark cases and made zero model calls because the records lacked the time-stamped
execution, dependency, runtime, provenance, and licensing evidence required for a defensible
author-policy mapping. This is an inclusion decision, not a naturalistic evaluation result; no
human annotators, human gold labels, or agreement statistic are claimed.

Post-gate correctness applies the same fixed policy as the benchmark oracle. It must not be
interpreted as model learning or independent prediction accuracy.
