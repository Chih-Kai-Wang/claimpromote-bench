#!/usr/bin/env python3
"""Validate anonymous compact v1/v2 result summaries."""

from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
V1 = ROOT / "results" / "v1-paper-results.json"
V2 = ROOT / "results" / "v2-public-pilot-study.json"
V3 = ROOT / "results" / "v2-gpt54-public-dev-followup.json"
MODELS = ("0.6B", "1.7B")
ARMS = ("narrative", "ledger", "ledger_verifier", "ledger_verifier_gate")
SEEDS = (104729, 130363, 169087)
EXPECTED_ERRORS = {
    ("0.6B", "narrative"): 900,
    ("0.6B", "ledger"): 261,
    ("0.6B", "ledger_verifier"): 335,
    ("0.6B", "ledger_verifier_gate"): 585,
    ("1.7B", "narrative"): 900,
    ("1.7B", "ledger"): 900,
    ("1.7B", "ledger_verifier"): 900,
    ("1.7B", "ledger_verifier_gate"): 546,
}


def fail(message: str) -> None:
    raise SystemExit(f"review-results: {message}")


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        fail(f"{path.name} is not a JSON object")
    return value


def close(observed: Any, expected: float, label: str) -> None:
    if not isinstance(observed, (int, float)) or isinstance(observed, bool):
        fail(f"{label} is not numeric")
    if not math.isclose(float(observed), expected, rel_tol=0.0, abs_tol=1e-12):
        fail(f"{label}: expected {expected}, got {observed}")


def validate_v1(value: dict[str, Any]) -> None:
    runs = value.get("runs")
    if not isinstance(runs, list) or len(runs) != 24:
        fail("v1 summary must contain 24 runs")
    seen: set[tuple[str, str, int]] = set()
    errors: Counter[tuple[str, str]] = Counter()
    python_versions: Counter[str] = Counter()
    total_errors = 0
    total_parseable = 0
    gate_cov: dict[str, list[float]] = defaultdict(list)
    gate_pair_cov: dict[str, list[float]] = defaultdict(list)
    for row in runs:
        identity = (str(row["m"]), str(row["a"]), int(row["s"]))
        if identity in seen:
            fail(f"duplicate v1 run: {identity}")
        seen.add(identity)
        format_errors = int(row["fe"])
        parseable = 300 - format_errors
        close(row["cov"], parseable / 300, f"{identity}.coverage")
        total_errors += format_errors
        total_parseable += parseable
        errors[(identity[0], identity[1])] += format_errors
        python_versions[str(row["py"])] += 1
        if parseable:
            close(row["fpr"], 1.0, f"{identity}.raw_fpr")
            close(row["vpr"], 1.0, f"{identity}.raw_vpr")
            close(row["pta"], 0.0, f"{identity}.raw_pta")
            if identity[1] == "ledger_verifier_gate":
                close(row["efpr"], 0.0, f"{identity}.effective_fpr")
                close(row["epta"], 1.0, f"{identity}.effective_pta")
                gate_cov[identity[0]].append(float(row["cov"]))
                gate_pair_cov[identity[0]].append(float(row["pcov"]))
        elif any(row.get(key) is not None for key in ("fpr", "vpr", "pta")):
            fail(f"undefined v1 rates are populated: {identity}")
    expected = {(model, arm, seed) for model in MODELS for arm in ARMS for seed in SEEDS}
    if seen != expected:
        fail("v1 run matrix is incomplete")
    if dict(errors) != EXPECTED_ERRORS:
        fail("v1 model/arm format-error totals changed")
    if (total_errors, total_parseable) != (5327, 1873):
        fail("v1 headline totals changed")
    if python_versions != Counter({"3.11.15": 21, "3.11.16": 3}):
        fail("v1 Python identity distribution changed")
    expected_ranges = {
        "0.6B": ((0.14, 0.49), (0.07333333333333333, 0.35333333333333333)),
        "1.7B": ((0.21666666666666667, 0.48333333333333334), (0.1, 0.38)),
    }
    for model, (coverage, pair_coverage) in expected_ranges.items():
        if (min(gate_cov[model]), max(gate_cov[model])) != coverage:
            fail(f"v1 {model} gate coverage range changed")
        if (min(gate_pair_cov[model]), max(gate_pair_cov[model])) != pair_coverage:
            fail(f"v1 {model} gate pair-coverage range changed")


def validate_v2(value: dict[str, Any]) -> None:
    if value.get("aggregate_status_counts") != {"OK": 108, "SCHEMA_ERROR": 52}:
        fail("v2 aggregate status counts changed")
    protocol = value.get("protocol")
    if not isinstance(protocol, dict) or protocol.get("total_decisions") != 160:
        fail("v2 protocol changed")
    runs = value.get("runs")
    if not isinstance(runs, list) or len(runs) != 4:
        fail("v2 must contain four run summaries")
    expected = {
        ("Qwen/Qwen3-0.6B", "free"): (0.75, 0.70, 30),
        ("Qwen/Qwen3-0.6B", "json_schema"): (1.0, 1.0, 40),
        ("Qwen/Qwen3-1.7B", "free"): (0.0, 0.0, 0),
        ("Qwen/Qwen3-1.7B", "json_schema"): (0.95, 0.90, 38),
    }
    constrained_ok = 0
    constrained_pairs = 0
    for row in runs:
        identity = (str(row["model_id"]), str(row["decoding_mode"]))
        if identity not in expected:
            fail(f"unexpected v2 run: {identity}")
        summary = row["summary"]
        coverage, pair_coverage, ok = expected[identity]
        close(summary["decision_coverage"], coverage, f"{identity}.coverage")
        close(summary["pair_coverage"], pair_coverage, f"{identity}.pair_coverage")
        if int(summary["status_counts"]["OK"]) != ok:
            fail(f"{identity} OK count changed")
        if ok:
            close(summary["raw_action_accuracy"], 0.5, f"{identity}.raw_accuracy")
            close(summary["raw_pair_accuracy"], 0.0, f"{identity}.pair_accuracy")
            close(summary["raw_flip_rate"], 0.0, f"{identity}.flip_rate")
            close(summary["raw_fpr"], 1.0, f"{identity}.raw_fpr")
            close(summary["raw_vpr"], 1.0, f"{identity}.raw_vpr")
        if identity[1] == "json_schema":
            constrained_ok += ok
            constrained_pairs += int(summary["covered_pairs"])
    if (constrained_ok, constrained_pairs) != (78, 38):
        fail("v2 constrained headline counts changed")


def validate_v3(value: dict[str, Any]) -> None:
    pilot = value.get("pilot")
    full = value.get("full")
    if not isinstance(pilot, dict) or not isinstance(full, dict):
        fail("GPT-5.4 follow-up summary is malformed")
    if (pilot.get("records"), pilot.get("parseable_decisions"), pilot.get("gate")) != (
        12,
        12,
        "GO",
    ):
        fail("GPT-5.4 pilot headline counts changed")
    expected_full = {
        "records": 100,
        "parseable_decisions": 99,
        "complete_pairs": 49,
        "raw_correct_decisions": 99,
        "raw_correct_pairs": 49,
        "false_promotions": 0,
        "invalid_promotion_trials": 49,
        "valid_promotions": 50,
        "valid_promotion_trials": 50,
    }
    for key, expected in expected_full.items():
        if full.get(key) != expected:
            fail(f"GPT-5.4 full result changed: {key}")
    close(full.get("decision_coverage"), 0.99, "GPT-5.4 decision coverage")
    close(full.get("pair_coverage"), 0.98, "GPT-5.4 pair coverage")
    for key in ("raw_action_accuracy", "raw_pair_accuracy", "raw_flip_rate"):
        close(full.get(key), 1.0, f"GPT-5.4 {key}")
    if full.get("status_counts") != {"OK": 99, "SCHEMA_ERROR": 1}:
        fail("GPT-5.4 status counts changed")
    if full.get("raw_action_distribution") != {
        "ALLOW": 50,
        "HOLD": 45,
        "DEMOTE": 2,
        "ESCALATE": 2,
    }:
        fail("GPT-5.4 action distribution changed")
    if full.get("routed_provider_values") != ["OpenAI"]:
        fail("GPT-5.4 routed provider changed")


def main() -> int:
    validate_v1(load(V1))
    validate_v2(load(V2))
    validate_v3(load(V3))
    print("review-results: PASS (v1 7,200; v2 160; GPT-5.4 100 decisions)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
