#!/usr/bin/env python3
"""Run public anonymous-review checks."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PYTHON_COMMANDS = [
    [sys.executable, "-m", "claimpromotebench", "validate", "data/alpha"],
    [
        sys.executable,
        "scripts/audit_public_pair_contracts.py",
        "--dataset",
        "data/alpha",
        "--out",
        "work/public-pair-contract-audit.json",
    ],
    [
        sys.executable,
        "-m",
        "claimpromotebench.shortcuts",
        "--dataset",
        "data/alpha",
        "--out",
        "work/shortcut-audit.json",
    ],
    [
        sys.executable,
        "-m",
        "claimpromotebench.invariance",
        "--dataset",
        "data/alpha",
        "--out",
        "work/invariance-audit.json",
    ],
    [
        sys.executable,
        "-m",
        "claimpromotebench.executable",
        "--fixtures",
        "fixtures/executable",
        "--out",
        "work/executable-fixtures.json",
    ],
    [sys.executable, "scripts/validate_anonymous_empirical_evidence.py"],
    [
        sys.executable,
        "scripts/validate_v2_naturalistic_candidates.py",
        "--registry",
        "v2/naturalistic-sources.json",
        "--pool",
        "v2/naturalistic-candidates.json",
        "--out",
        "work/naturalistic-candidate-validation.json",
    ],
    [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "tests/test_v2.py",
        "tests/test_v2_naturalistic.py",
    ],
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--python-only",
        action="store_true",
        help="run a partial replay without the pinned Lean checks",
    )
    args = parser.parse_args()
    (ROOT / "work").mkdir(exist_ok=True)
    env = os.environ.copy()
    package_root = str(ROOT / "src")
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = (
        package_root + os.pathsep + existing_pythonpath
        if existing_pythonpath
        else package_root
    )
    for command in PYTHON_COMMANDS:
        print("+", " ".join(command), flush=True)
        subprocess.run(command, cwd=ROOT, check=True, env=env)
    if args.python_only:
        print("anonymous-review-checks: PARTIAL_PASS (Python only; Lean explicitly skipped)")
        return 0

    lake = shutil.which("lake")
    if lake is None:
        raise SystemExit(
            "anonymous-review-checks: lake is required for full replay; "
            "install Lean or pass --python-only for a partial replay"
        )
    formal_root = ROOT / "data" / "alpha"
    formal_commands = [
        [lake, "build"],
        [lake, "env", "leanchecker", "ClaimPromoteFormal"],
        [
            sys.executable,
            "-m",
            "claimpromotebench.formal",
            "--dataset",
            "data/alpha",
            "--fixtures",
            "fixtures/formal/cases.json",
            "--out",
            "work/formal-fixtures.json",
        ],
    ]
    for command in formal_commands:
        print("+", " ".join(command), flush=True)
        cwd = formal_root if command[0] == lake else ROOT
        subprocess.run(command, cwd=cwd, check=True, env=env)
    print("anonymous-review-checks: PASS (Python and Lean)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
