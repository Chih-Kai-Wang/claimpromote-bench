#!/usr/bin/env python3
"""Recompute the paper-facing studies from anonymous item-level records."""
from __future__ import annotations
import hashlib
import json
import math
import re
from collections import Counter
from copy import deepcopy
from pathlib import Path
from typing import Any, NoReturn
from analyze_balanced_public_challenge import derive_reporting_metrics as derive_balanced_metrics
from analyze_confirmatory_hidden_study import analyze as analyze_fresh_confirmatory
from claimpromotebench.dataset import validate_with_schema
from claimpromotebench.hashing import canonical_json
ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence'
Json = dict[str, Any]
ACTIONS = ('ALLOW', 'HOLD', 'DEMOTE', 'ESCALATE')

def fail(message: str) -> NoReturn:
    raise SystemExit(f'anonymous-empirical-evidence: {message}')

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))

def load_jsonl(path: Path) -> list[Json]:
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
    if any((not isinstance(row, dict) for row in rows)):
        fail(f'non-object JSONL record: {path.relative_to(ROOT)}')
    return rows

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return 'sha256:' + digest.hexdigest()

def sha256_text(value: str) -> str:
    return 'sha256:' + hashlib.sha256(value.encode('utf-8')).hexdigest()

def validate_self_digest(value: Json, field: str, label: str) -> None:
    payload = {key: child for key, child in value.items() if key != field}
    if value.get(field) != sha256_text(canonical_json(payload)):
        fail(f'{label}: self-digest changed')

def equivalent_json(left: Any, right: Any) -> bool:
    """Compare recomputed JSON while tolerating only machine-scale float summation drift."""
    if isinstance(left, bool) or isinstance(right, bool):
        return left is right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isclose(float(left), float(right), rel_tol=1e-12, abs_tol=1e-12)
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all((equivalent_json(left[key], right[key]) for key in left))
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all((equivalent_json(left_value, right_value) for left_value, right_value in zip(left, right, strict=True)))
    return bool(left == right)

def validate_raw_response_hashes(rows: list[Json], label: str) -> None:
    for row in rows:
        raw = row.get('raw_response_text')
        observed = row.get('raw_response_sha256')
        if raw is None:
            if observed is not None:
                fail(f'{label}: null raw response has a digest')
        elif observed != sha256_text(str(raw)):
            fail(f"{label}: raw response digest mismatch for {row.get('item_id')}")

def validate_prompt_binding(rows: list[Json], packet_path: Path, label: str) -> None:
    packet = load_json(packet_path)
    if not isinstance(packet, dict) or not isinstance(packet.get('records'), list):
        fail(f'{label}: malformed prompt packet')
    prompts = {str(row['item_id']): str(row['prompt_sha256']) for row in packet['records']}
    for row in rows:
        item_id = str(row.get('item_id'))
        if item_id not in prompts or row.get('prompt_sha256') != prompts[item_id]:
            fail(f'{label}: prompt binding mismatch for {item_id}')

def reject_hidden_reasoning(value: Any, label: str) -> None:
    if isinstance(value, dict):
        forbidden = {'reasoning_content', 'thinking', 'thinking_content', 'thought', 'thoughts'}
        overlap = forbidden & set(value)
        if overlap:
            fail(f'{label}: hidden reasoning fields survived: {sorted(overlap)}')
        if str(value.get('type', '')).lower() in {'reasoning', 'thinking'}:
            fail(f'{label}: hidden reasoning content block survived')
        for child in value.values():
            reject_hidden_reasoning(child, label)
    elif isinstance(value, list):
        for child in value:
            reject_hidden_reasoning(child, label)

def _fresh_scientific_projection(value: Json) -> Json:
    projected = deepcopy(value)
    projected.pop('aggregate_sha256', None)
    projected.pop('source_identity', None)
    scores = projected.get('scores')
    if isinstance(scores, dict):
        for score in scores.values():
            if isinstance(score, dict):
                score.pop('run_sha256', None)
    return projected

def validate_fresh_confirmatory() -> Json:
    root = EVIDENCE / 'fresh-confirmatory'
    manifest_path = root / 'MANIFEST.json'
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict):
        fail('fresh confirmatory evidence manifest is malformed')
    manifest_payload = deepcopy(manifest)
    observed_manifest_sha = manifest_payload.pop('manifest_sha256', None)
    if observed_manifest_sha != sha256_text(canonical_json(manifest_payload)):
        fail('fresh confirmatory evidence manifest self-digest changed')
    actual_files = {path.relative_to(root).as_posix(): sha256_file(path) for path in sorted(root.rglob('*')) if path.is_file() and path != manifest_path}
    if manifest['files'] != actual_files or manifest.get('file_count') != len(actual_files):
        fail('fresh confirmatory evidence manifest coverage changed')
    scope = manifest.get('scope', {})
    if scope.get('hidden_reasoning_included') is not False or scope.get('raw_final_response_text_included') is not False or scope.get('free_form_error_text_included') is not False or (scope.get('all_scheduled_terminal_failures_included') is not True):
        fail('fresh confirmatory anonymous scope changed')
    dataset = root / 'dataset'
    dataset_manifest = load_json(dataset / 'manifest.json')
    if not isinstance(dataset_manifest, dict) or not isinstance(dataset_manifest.get('files'), dict):
        fail('fresh confirmatory dataset manifest is malformed')
    for relative, expected in dataset_manifest['files'].items():
        path = dataset / relative
        if not path.is_file() or sha256_file(path) != expected:
            fail(f'fresh confirmatory dataset file digest changed: {relative}')
    inputs = load_jsonl(dataset / 'inputs.jsonl')
    gold = load_jsonl(dataset / 'gold.jsonl')
    pairs = load_json(dataset / 'pairs.json')
    if not isinstance(pairs, list):
        fail('fresh confirmatory pair file is malformed')
    input_ids = {str(row['id']) for row in inputs}
    gold_ids = {str(row['id']) for row in gold}
    pair_ids = {str(row['pair_id']) for row in pairs}
    if len(input_ids) != 300 or input_ids != gold_ids or len(pair_ids) != 150:
        fail('fresh confirmatory dataset coverage changed')
    if any((not re.fullmatch('v1-test-cfo-\\d{3}-[ab]', item_id) for item_id in input_ids)):
        fail('fresh confirmatory item namespace differs from released cfo IDs')
    if any((not re.fullmatch('v1-test-cfo-\\d{3}', pair_id) for pair_id in pair_ids)):
        fail('fresh confirmatory pair namespace differs from released cfo IDs')
    correction = load_json(root / 'frozen-manifest-metadata-correction.json')
    if not isinstance(correction, dict):
        fail('fresh confirmatory frozen-manifest correction is malformed')
    correction_payload = deepcopy(correction)
    observed_correction_sha = correction_payload.pop('self_digest', None)
    if observed_correction_sha != sha256_text(canonical_json(correction_payload)):
        fail('fresh confirmatory frozen-manifest correction self-digest changed')
    if correction.get('source_manifest_sha256') != sha256_file(dataset / 'manifest.json') or correction.get('coverage_check', {}).get('item_ids_matching_observed_pattern') != 300 or correction.get('coverage_check', {}).get('pair_ids_matching_observed_pattern') != 150 or (correction.get('scientific_impact') != 'NONE'):
        fail('fresh confirmatory frozen-manifest correction does not match the dataset')
    c2 = load_json(root / 'c2-receipt-review.json')
    if not isinstance(c2, dict) or (c2.get('analysis_executed_before_receipt') is not False or c2.get('gold_loaded_before_receipt') is not False or c2.get('contains_gold_labels') is not False or (c2.get('planned_cells') != 600) or (c2.get('sealed_cells') != 600) or (c2.get('outcome_counts') != {'RESPONSE_RECORDED': 600})):
        fail('fresh confirmatory anonymous C2 receipt changed')
    expected_lanes = {'opencode-go-deepseek-v4-flash-matched', 'opencode-go-qwen3.7-max'}
    lane_files = manifest.get('lane_files')
    if not isinstance(lane_files, dict) or set(lane_files) != expected_lanes:
        fail('fresh confirmatory lane manifest changed')
    rows_by_lane: dict[str, list[Json]] = {}
    run_paths: list[Path] = []
    for lane_id, relative in sorted(lane_files.items()):
        path = root / str(relative)
        rows = load_jsonl(path)
        run_paths.append(path)
        if len(rows) != 300 or {str(row.get('lane_id')) for row in rows} != {lane_id} or {str(row.get('item_id')) for row in rows} != input_ids:
            fail(f'fresh confirmatory projected run coverage changed: {lane_id}')
        for row in rows:
            reject_hidden_reasoning(row, f'fresh confirmatory {lane_id}')
            if row.get('application_post_count') != 1 or row.get('client_retry_count') != 0:
                fail(f'fresh confirmatory request accounting changed: {lane_id}')
            if row.get('redirect_followed') is not False:
                fail(f'fresh confirmatory redirect boundary changed: {lane_id}')
            if any((row.get(field) is not None for field in ('raw_final_text', 'raw_final_text_sha256', 'parse_detail', 'network_error'))):
                fail(f'fresh confirmatory retained raw or free-form response content: {lane_id}')
            raw_text = row.get('raw_final_text')
            raw_sha = row.get('raw_final_text_sha256')
            if raw_text is None:
                if raw_sha is not None:
                    fail(f'fresh confirmatory null final text has a digest: {lane_id}')
            elif raw_sha != sha256_text(str(raw_text)):
                fail(f'fresh confirmatory final-text digest changed: {lane_id}')
        rows_by_lane[lane_id] = rows
    qwen_id = 'opencode-go-qwen3.7-max'
    flash_id = 'opencode-go-deepseek-v4-flash-matched'
    qwen = rows_by_lane[qwen_id]
    flash = rows_by_lane[flash_id]
    if Counter((str(row.get('parse_status')) for row in qwen)) != Counter({'OK': 272, 'HTTP_ERROR': 15, 'TRANSPORT_ERROR': 10, 'SEMANTIC_ERROR': 3}):
        fail('fresh confirmatory Qwen parser-status distribution changed')
    if Counter((row.get('http_status') for row in qwen)) != Counter({200: 275, 500: 14, 503: 1, None: 10}):
        fail('fresh confirmatory Qwen HTTP-status distribution changed')
    if Counter((str(row.get('parse_status')) for row in flash)) != Counter({'HTTP_ERROR': 300}):
        fail('fresh confirmatory Flash parser-status distribution changed')
    if Counter((row.get('http_status') for row in flash)) != Counter({401: 300}):
        fail('fresh confirmatory Flash HTTP-status distribution changed')
    qwen_usage = [row['usage'] for row in qwen if isinstance(row.get('usage'), dict) and isinstance(row['usage'].get('input_tokens'), int)]
    if len(qwen_usage) != 275 or sum((int(row.get('input_tokens', 0)) for row in qwen_usage)) != 662053 or sum((int(row.get('output_tokens', 0)) for row in qwen_usage)) != 613618 or (sum((int(row.get('output_tokens', 0)) > 1536 for row in qwen_usage)) != 261):
        fail('fresh confirmatory Qwen provider-reported usage changed')
    plan = load_json(root / 'study-plan.json')
    packet = load_json(root / 'prompt-packet.json')
    baselines = load_json(root / 'baselines.json')
    reported = load_json(root / 'reported-analysis.json')
    if not all((isinstance(value, dict) for value in (plan, packet, baselines, reported))):
        fail('fresh confirmatory plan, packet, baseline, or analysis is malformed')
    recomputed = analyze_fresh_confirmatory(dataset, packet, plan, baselines, run_paths)
    if not equivalent_json(_fresh_scientific_projection(recomputed), _fresh_scientific_projection(reported)):
        fail('fresh confirmatory reported science differs from projected C2 records')
    study_result = load_json(root / 'study-result.json')
    reporting_addendum = load_json(root / 'reporting-addendum.json')
    redaction = load_json(root / 'redaction-receipt-review.json')
    if not all((isinstance(value, dict) for value in (study_result, reporting_addendum, redaction))):
        fail('fresh confirmatory study result, reporting addendum, or redaction receipt is malformed')
    addendum_payload = deepcopy(reporting_addendum)
    observed_addendum_sha = addendum_payload.pop('self_digest', None)
    if observed_addendum_sha != sha256_text(canonical_json(addendum_payload)):
        fail('fresh confirmatory reporting addendum self-digest changed')
    qwen_score = recomputed['scores'][qwen_id]['raw']
    qwen_test = next((row for row in recomputed['confirmatory_item_correctness_tests']['tests'] if row['model_lane'] == qwen_id))
    qwen_summary = study_result.get('qwen_service_configuration', {})
    flash_summary = study_result.get('deepseek_flash_service_configuration', {})
    gold_actions = {str(row['id']): str(row['decision']['action']) for row in gold}
    qwen_predictions = {str(row['item_id']): str(row['raw_decision']['action']) if row.get('parse_status') == 'OK' and isinstance(row.get('raw_decision'), dict) else None for row in qwen}
    complete_pairs = [pair for pair in pairs if all((qwen_predictions[str(item_id)] in ACTIONS for item_id in pair['member_ids']))]
    correct_pairs = [pair for pair in pairs if all((qwen_predictions[str(item_id)] == gold_actions[str(item_id)] for item_id in pair['member_ids']))]
    factor_support: dict[str, Counter[str]] = {action: Counter() for action in ACTIONS}
    factor_counts: dict[str, Json] = {}
    for pair in pairs:
        factor_id = str(pair['factor_id'])
        invalid_action = gold_actions[str(pair['invalid_id'])]
        factor_support[invalid_action][factor_id] += 1
        factor = factor_counts.setdefault(factor_id, {'factor_id': factor_id, 'family': str(pair['family']), 'invalid_action': invalid_action, 'pairs': 0, 'covered_pairs': 0, 'correct_pairs': 0})
        member_ids = [str(item_id) for item_id in pair['member_ids']]
        factor['pairs'] += 1
        factor['covered_pairs'] += int(all((qwen_predictions[item_id] in ACTIONS for item_id in member_ids)))
        factor['correct_pairs'] += int(all((qwen_predictions[item_id] == gold_actions[item_id] for item_id in member_ids)))
    factor_metrics: list[Json] = []
    for factor_id in sorted(factor_counts):
        factor = factor_counts[factor_id]
        covered = int(factor['covered_pairs'])
        pair_count = int(factor['pairs'])
        pair_correct = int(factor['correct_pairs'])
        factor_metrics.append({**factor, 'pair_coverage': covered / pair_count, 'end_to_end_pair_accuracy': pair_correct / pair_count, 'conditional_pair_accuracy': pair_correct / covered if covered else None})
    qwen_addendum = reporting_addendum.get('qwen_service_configuration', {})
    policy_ceiling = reporting_addendum.get('deterministic_policy_executor', {})
    if not equivalent_json(qwen_summary.get('end_to_end_item_accuracy'), qwen_score['item_accuracy']) or not equivalent_json(qwen_summary.get('end_to_end_pair_accuracy'), qwen_score['pair_accuracy']) or (not equivalent_json(qwen_summary.get('decision_coverage'), qwen_score['decision_coverage'])) or (qwen_score['per_action']['DEMOTE']['correct'] != 0) or (not equivalent_json(qwen_summary.get('superiority_test_vs_public_dev_text_nb', {}).get('holm_adjusted_p'), qwen_test['holm_adjusted_p'])) or (flash_summary.get('model_capability_interpretation') != 'NON_EVALUABLE_NO_MODEL_OUTPUT') or (flash_summary.get('http_401_records') != 300) or (qwen_addendum.get('valid_decisions') != 272) or (qwen_addendum.get('correct_items') != 258) or (qwen_addendum.get('complete_pairs') != len(complete_pairs)) or (len(complete_pairs) != 123) or (qwen_addendum.get('correct_pairs') != len(correct_pairs)) or (len(correct_pairs) != 113) or (not equivalent_json(qwen_addendum.get('conditional_item_accuracy_given_valid_decision'), 258 / 272)) or (not equivalent_json(qwen_addendum.get('conditional_pair_accuracy_given_complete_pair'), 113 / 123)) or (qwen_addendum.get('confusion') != qwen_score['confusion']) or (qwen_addendum.get('factor_metrics') != factor_metrics) or (reporting_addendum.get('invalid_action_factor_support') != {action: dict(sorted(counts.items())) for action, counts in factor_support.items() if counts}) or (policy_ceiling.get('role') != 'DEFINITIONAL_POLICY_CEILING_NOT_A_LEARNED_EMPIRICAL_BASELINE') or (policy_ceiling.get('correct_items') != 300) or (policy_ceiling.get('correct_pairs') != 150):
        fail('fresh confirmatory compact study result or reporting addendum differs from recomputation')
    if redaction.get('hidden_reasoning_present_in_public_release') is not False or redaction.get('original_scored_artifacts_modified') is not False or redaction.get('post_c2_transform') is not True or (redaction.get('public_provider_envelopes_allowlisted') is not True) or (redaction.get('redacted_unique_model_item_cells') != 275) or (redaction.get('removed_content_blocks_including_raw_and_c2_copies') != 550) or (redaction.get('scientific_analysis_payload_byte_identical') is not True) or (redaction.get('source_to_derived_row_hashes_verified_before_anonymization') is not True):
        fail('fresh confirmatory anonymous redaction receipt changed')
    return {'c2_sealed_cells': c2['sealed_cells'], 'flash_http_401_records': 300, 'flash_model_efficacy': 'NON_EVALUABLE', 'qwen_decision_coverage': qwen_score['decision_coverage'], 'qwen_demote_correct': qwen_score['per_action']['DEMOTE']['correct'], 'qwen_item_accuracy': qwen_score['item_accuracy'], 'qwen_conditional_item_accuracy': qwen_addendum['conditional_item_accuracy_given_valid_decision'], 'qwen_pair_coverage': qwen_addendum['pair_coverage'], 'qwen_pair_accuracy': qwen_score['pair_accuracy'], 'qwen_factor_count': len(factor_metrics), 'qwen_conditional_pair_accuracy': qwen_addendum['conditional_pair_accuracy_given_complete_pair'], 'qwen_vs_public_dev_nb_holm_p': qwen_test['holm_adjusted_p'], 'redaction_status': redaction['status']}

def validate_balanced_public_challenge() -> Json:
    root = EVIDENCE / 'balanced-public-challenge'
    manifest = load_json(root / 'MANIFEST.json')
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict):
        fail('balanced challenge manifest is malformed')
    manifest_payload = deepcopy(manifest)
    observed_manifest_sha = manifest_payload.pop('manifest_sha256', None)
    if observed_manifest_sha != sha256_text(canonical_json(manifest_payload)):
        fail('balanced challenge manifest self-digest changed')
    declared = manifest['files']
    actual = {path.relative_to(root).as_posix(): sha256_file(path) for path in sorted(root.rglob('*')) if path.is_file() and path.name != 'MANIFEST.json'}
    if manifest.get('file_count') != len(actual) or declared != actual:
        fail('balanced challenge manifest differs from the generated tree')
    scope = manifest.get('scope', {})
    if scope.get('hidden_reasoning_included') is not False or scope.get('provider_response_identifiers_included') is not False or scope.get('source_artifact_or_workflow_ids_included') is not False or (scope.get('raw_final_response_text_included') is not False) or (scope.get('free_form_error_text_included') is not False) or (scope.get('all_scheduled_terminal_failures_included') is not True):
        fail('balanced challenge anonymous scope changed')
    dataset = root / 'dataset'
    inputs = load_jsonl(dataset / 'inputs.jsonl')
    gold = load_jsonl(dataset / 'gold.jsonl')
    pairs = load_json(dataset / 'pairs.json')
    plan = load_json(root / 'study-plan.json')
    packet = load_json(root / 'prompt-packet.json')
    aggregate = load_json(root / 'reported-aggregate.json')
    correction = load_json(root / 'reporting-correction-review.json')
    receipt = load_json(root / 'privacy-receipt-review.json')
    if not all((isinstance(value, dict) for value in (plan, packet, aggregate, correction, receipt))):
        fail('balanced challenge plan, packet, aggregate, correction, or receipt is malformed')
    if not isinstance(pairs, list):
        fail('balanced challenge pairs are malformed')
    input_ids = {str(row['id']) for row in inputs}
    gold_by_id = {str(row['id']): row for row in gold}
    pair_ids = {str(row['pair_id']) for row in pairs}
    factor_ids = {str(row['factor_id']) for row in pairs}
    if len(input_ids) != 180 or input_ids != set(gold_by_id) or len(pair_ids) != 90 or (len(factor_ids) != 15):
        fail('balanced challenge dataset coverage changed')
    action_counts = Counter((str(row['decision']['action']) for row in gold))
    if action_counts != Counter({'ALLOW': 90, 'HOLD': 30, 'DEMOTE': 30, 'ESCALATE': 30}):
        fail('balanced challenge gold action distribution changed')
    if plan.get('status') != 'FROZEN_BEFORE_SCORED_INFERENCE' or plan.get('design', {}).get('attempts_per_item') != 1 or plan.get('design', {}).get('held_out_generalization_claim') is not False or (plan.get('statistics', {}).get('failure_rule') != 'Every non-OK response remains in the denominator as incorrect.'):
        fail('balanced challenge plan boundary changed')
    packet_rows = packet.get('records')
    if not isinstance(packet_rows, list) or {str(row.get('item_id')) for row in packet_rows} != input_ids:
        fail('balanced challenge prompt-packet coverage changed')
    lane_files = manifest.get('lane_files')
    analysis_files = manifest.get('analysis_files')
    expected_lanes = {'opencode-go-deepseek-v4-flash-matched', 'opencode-go-qwen3.7-max'}
    if not isinstance(lane_files, dict) or not isinstance(analysis_files, dict) or set(lane_files) != expected_lanes or (set(analysis_files) != expected_lanes):
        fail('balanced challenge lane manifest changed')
    aggregate_lanes = {str(row.get('lane_id')): row for row in aggregate.get('lanes', []) if isinstance(row, dict)}
    if set(aggregate_lanes) != expected_lanes:
        fail('balanced challenge aggregate lane set changed')
    lane_metrics: dict[str, Json] = {}
    for lane_id in sorted(expected_lanes):
        run_path = root / str(lane_files[lane_id])
        rows = load_jsonl(run_path)
        if len(rows) != 180 or {str(row.get('item_id')) for row in rows} != input_ids or {str(row.get('lane_id')) for row in rows} != {lane_id}:
            fail(f'balanced challenge run coverage changed: {lane_id}')
        validate_raw_response_hashes(rows, f'balanced challenge {lane_id}')
        validate_prompt_binding(rows, root / 'prompt-packet.json', f'balanced challenge {lane_id}')
        for row in rows:
            item_id = str(row.get('item_id'))
            validate_with_schema(row, ROOT / 'v2' / 'schemas' / 'stronger-model-run-record.schema.json', item_id)
            reject_hidden_reasoning(row, f'balanced challenge {lane_id}')
            if row.get('provider_response_id') is not None:
                fail(f'balanced challenge retained a provider response ID: {item_id}')
            if any((row.get(field) is not None for field in ('raw_response_text', 'raw_response_sha256', 'parse_error_detail', 'transport_error'))):
                fail(f'balanced challenge retained raw or free-form response content: {item_id}')
        metrics = derive_balanced_metrics(gold, pairs, rows)
        if not equivalent_json(metrics, aggregate_lanes[lane_id].get('metrics')):
            fail(f'balanced challenge aggregate differs from item-level records: {lane_id}')
        if aggregate_lanes[lane_id].get('run_sha256') != sha256_file(run_path):
            fail(f'balanced challenge aggregate run digest changed: {lane_id}')
        analysis_path = root / str(analysis_files[lane_id])
        analysis = load_json(analysis_path)
        if not isinstance(analysis, dict) or analysis.get('lane_id') != lane_id or analysis.get('run_sha256') != sha256_file(run_path):
            fail(f'balanced challenge lane analysis binding changed: {lane_id}')
        lane_metrics[lane_id] = metrics
    qwen = lane_metrics['opencode-go-qwen3.7-max']
    flash = lane_metrics['opencode-go-deepseek-v4-flash-matched']
    if correction.get('status') != 'REPORTING_CORRECTION' or correction.get('source_identity') != 'WITHHELD_DURING_DOUBLE_BLIND_REVIEW' or correction.get('metric_convention') != 'FIXED_FOUR_CLASS_MACRO_F1_WITH_ZERO_DIVISION_EQUAL_TO_ZERO' or (correction.get('scope', {}).get('model_calls_performed') != 0) or (correction.get('scope', {}).get('raw_or_terminal_records_changed') is not False) or (correction.get('scope', {}).get('primary_endpoints_changed') is not False) or (correction.get('anonymous_run_sha256') != {lane_id: sha256_file(root / str(lane_files[lane_id])) for lane_id in sorted(expected_lanes)}):
        fail('balanced challenge reporting-correction boundary changed')
    affected = correction.get('affected_lanes', {}).get('opencode-go-deepseek-v4-flash-matched', {})
    if affected.get('historical') != {'conditional_macro_f1': 0.6243032962151766, 'macro_f1': 0.5236761371215153, 'per_action.DEMOTE.conditional_f1': None, 'per_action.DEMOTE.end_to_end_f1': None, 'per_action.DEMOTE.precision': None} or affected.get('corrected') != {'conditional_macro_f1': flash['conditional_macro_f1'], 'macro_f1': flash['macro_f1'], 'per_action.DEMOTE.conditional_f1': flash['per_action']['DEMOTE']['conditional_f1'], 'per_action.DEMOTE.end_to_end_f1': flash['per_action']['DEMOTE']['end_to_end_f1'], 'per_action.DEMOTE.precision': flash['per_action']['DEMOTE']['precision']}:
        fail('balanced challenge reporting-correction values changed')
    expected_qwen = {'parseable_items': 148, 'correct_items': 132, 'covered_pairs': 64, 'correct_pairs': 48, 'end_to_end_item_accuracy': 0.7333333333333333, 'conditional_item_accuracy': 0.8918918918918919, 'end_to_end_pair_accuracy': 0.5333333333333333, 'conditional_pair_accuracy': 0.75}
    expected_flash = {'parseable_items': 146, 'correct_items': 90, 'covered_pairs': 61, 'correct_pairs': 13, 'end_to_end_item_accuracy': 0.5, 'conditional_item_accuracy': 0.6164383561643836, 'end_to_end_pair_accuracy': 0.14444444444444443, 'conditional_pair_accuracy': 0.21311475409836064, 'macro_f1': 0.39275710284113646, 'conditional_macro_f1': 0.46822747216138244}
    for label, observed, expected in (('Qwen', qwen, expected_qwen), ('Flash', flash, expected_flash)):
        for key, value in expected.items():
            if not equivalent_json(observed.get(key), value):
                fail(f'balanced challenge {label} metric changed: {key}')
    validation = receipt.get('validation', {})
    if receipt.get('source_artifact_or_workflow_ids_included') is not False or receipt.get('raw_final_response_text_included') is not False or receipt.get('free_form_error_text_included') is not False or (receipt.get('all_scheduled_terminal_failures_included') is not True) or (validation.get('terminal_records_validated') != 360) or (validation.get('provider_account_identifier_findings') != 0) or (validation.get('retained_provider_response_ids') != 0) or (validation.get('hidden_reasoning_field_findings') != 0):
        fail('balanced challenge privacy receipt changed')
    if aggregate.get('design') != 'PUBLIC_PRECOMMITTED_BALANCED_CHALLENGE' or aggregate.get('service_comparison', {}).get('causal_model_ablation_claimed') is not False or aggregate.get('deterministic_policy_executor', {}).get('label') != 'DEFINITIONAL_POLICY_CEILING_NOT_A_LEARNED_EMPIRICAL_BASELINE':
        fail('balanced challenge interpretation boundary changed')
    return {'items_per_lane': 180, 'pairs_per_lane': 90, 'qwen_valid_decisions': qwen['parseable_items'], 'qwen_end_to_end_item_accuracy': qwen['end_to_end_item_accuracy'], 'qwen_end_to_end_pair_accuracy': qwen['end_to_end_pair_accuracy'], 'flash_valid_decisions': flash['parseable_items'], 'flash_end_to_end_item_accuracy': flash['end_to_end_item_accuracy'], 'flash_end_to_end_pair_accuracy': flash['end_to_end_pair_accuracy'], 'privacy_status': receipt['status']}

def changed_paths(left: Any, right: Any, prefix: str='') -> list[str]:
    if type(left) is not type(right):
        return [prefix or '/']
    if isinstance(left, dict):
        if set(left) != set(right):
            return [prefix or '/']
        paths: list[str] = []
        for key in left:
            paths.extend(changed_paths(left[key], right[key], f'{prefix}/{key}'))
        return paths
    if isinstance(left, list):
        if len(left) != len(right):
            return [prefix or '/']
        paths = []
        for index, (left_value, right_value) in enumerate(zip(left, right, strict=True)):
            paths.extend(changed_paths(left_value, right_value, f'{prefix}/{index}'))
        return paths
    return [] if left == right else [prefix or '/']

def baseline_records(predictions: list[Json]) -> list[Json]:
    return [{'item_id': row['item_id'], 'pair_id': row['pair_id'], 'parse_status': 'OK', 'raw_decision': {'action': row['predicted_action']}} for row in predictions]

def validate_synthetic_policy_evidence(study_kind: str) -> Json:
    specifications = {'SLSA_DERIVED_POLICY_PORTABILITY': {'directory': 'slsa-portability', 'aggregate_design': 'PROSPECTIVELY_FROZEN_SECOND_POLICY_PORTABILITY_STUDY', 'plan_status': 'FROZEN_BEFORE_SCORED_INFERENCE', 'baseline_files': {'structured': 'predictions.jsonl'}, 'aggregate_baseline_key': 'structured_random_forest_action_baseline', 'controlled_path': 'evidence_field', 'run_schema': 'stronger-model-run-record.schema.json'}, 'COUNTERFACTUAL_POLICY_PROFILE_SWITCH': {'directory': 'policy-switch', 'aggregate_design': 'PROSPECTIVELY_FROZEN_COUNTERFACTUAL_POLICY_PROFILE_STUDY', 'plan_status': 'FROZEN_BEFORE_SCORED_INFERENCE', 'baseline_files': {'policy_aware': 'policy_aware-predictions.jsonl', 'profile_blind': 'profile_blind-predictions.jsonl'}, 'aggregate_baseline_key': 'structured_random_forest_comparators', 'controlled_path': 'active_profile', 'run_schema': 'stronger-model-run-record.schema.json'}, 'LOCAL_MODEL_SLSA_POLICY_REPLICATION': {'directory': 'local-model-replications/slsa', 'aggregate_design': 'LOCAL_MODEL_REPLICATION_REPLACEMENT_V2_OF_FROZEN_SLSA_POLICY_STUDY', 'plan_status': 'PROSPECTIVELY_FROZEN_LOCAL_MODEL_REPLICATION_REPLACEMENT_V2', 'baseline_files': {'structured': 'predictions.jsonl'}, 'aggregate_baseline_key': 'structured_random_forest_action_baseline', 'controlled_path': 'evidence_field', 'run_schema': 'local-model-run-record.schema.json', 'replacement_version': 2}, 'LOCAL_MODEL_POLICY_SWITCH_REPLICATION': {'directory': 'local-model-replications/policy-switch', 'aggregate_design': 'LOCAL_MODEL_REPLICATION_REPLACEMENT_V2_OF_FROZEN_POLICY_SWITCH_STUDY', 'plan_status': 'PROSPECTIVELY_FROZEN_LOCAL_MODEL_REPLICATION_REPLACEMENT_V2', 'baseline_files': {'policy_aware': 'policy_aware-predictions.jsonl', 'profile_blind': 'profile_blind-predictions.jsonl'}, 'aggregate_baseline_key': 'structured_random_forest_comparators', 'controlled_path': 'active_profile', 'run_schema': 'local-model-run-record.schema.json', 'replacement_version': 2}, 'LOCAL_MODEL_POLICY_TRANSITION_GRAPH_REPLICATION': {'directory': 'local-model-replications/policy-transition-graph', 'aggregate_design': 'LOCAL_MODEL_EVALUATION_OF_FROZEN_REACHABLE_POLICY_TRANSITION_GRAPH', 'plan_status': 'PROSPECTIVELY_FROZEN_LOCAL_MODEL_REPLICATION_REPLACEMENT_V2', 'baseline_files': {'policy_aware': 'policy_aware-predictions.jsonl', 'profile_blind': 'profile_blind-predictions.jsonl'}, 'aggregate_baseline_key': 'structured_random_forest_comparators', 'controlled_path': 'active_profile', 'run_schema': 'local-model-run-record.schema.json', 'replacement_version': 2, 'action_support': {'ALLOW': 36, 'HOLD': 24, 'DEMOTE': 24, 'ESCALATE': 36}, 'factor_count': 10, 'pair_requires_allow': False, 'transition_graph': True, 'baseline_correct': {'policy_aware': {'items': 107, 'pairs': 47}, 'profile_blind': {'items': 57, 'pairs': 0}}}}
    specification = specifications[study_kind]
    root = EVIDENCE / str(specification['directory'])
    manifest = load_json(root / 'MANIFEST.json')
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict):
        fail(f'{study_kind}: manifest is malformed')
    manifest_payload = deepcopy(manifest)
    observed_manifest_sha = manifest_payload.pop('manifest_sha256', None)
    if observed_manifest_sha != sha256_text(canonical_json(manifest_payload)):
        fail(f'{study_kind}: manifest self-digest changed')
    actual_files = {path.relative_to(root).as_posix(): sha256_file(path) for path in sorted(root.rglob('*')) if path.is_file() and path != root / 'MANIFEST.json'}
    if manifest.get('file_count') != len(actual_files) or manifest.get('files') != actual_files:
        fail(f'{study_kind}: manifest differs from the generated tree')
    if manifest.get('study_kind') != study_kind or manifest.get('status') != 'ANONYMOUS_SYNTHETIC_POLICY_EVIDENCE':
        fail(f'{study_kind}: manifest identity changed')
    expected_scope = {'credentials_included': False, 'hidden_reasoning_included': False, 'provider_response_identifiers_included': False, 'source_repository_or_commit_identity_included': False, 'raw_final_response_text_included': False, 'item_level_structured_decisions_included': True, 'all_scheduled_terminal_failures_included': True}
    if manifest.get('scope') != expected_scope:
        fail(f'{study_kind}: anonymous scope changed')
    dataset = root / 'dataset'
    items = load_jsonl(dataset / 'evaluation-items.jsonl')
    gold = load_jsonl(dataset / 'evaluation-gold.jsonl')
    pairs = load_json(dataset / 'evaluation-pairs.json')
    packet = load_json(dataset / 'evaluation-prompt-packet.json')
    dataset_manifest = load_json(dataset / 'manifest.json')
    plan = load_json(root / 'study-plan.json')
    schedule = load_json(root / 'request-schedule.json')
    aggregate = load_json(root / 'reported-aggregate.json')
    receipt = load_json(root / 'execution-receipt.json')
    if not all((isinstance(value, dict) for value in (packet, dataset_manifest, plan, schedule, aggregate, receipt))):
        fail(f'{study_kind}: plan, packet, schedule, aggregate, or receipt is malformed')
    if not isinstance(pairs, list):
        fail(f'{study_kind}: evaluation pairs are malformed')
    item_by_id = {str(row['id']): row for row in items}
    gold_by_id = {str(row['id']): row for row in gold}
    if len(items) != 120 or len(item_by_id) != 120 or set(item_by_id) != set(gold_by_id):
        fail(f'{study_kind}: evaluation item coverage changed')
    expected_action_support = Counter(specification.get('action_support', {'ALLOW': 60, 'HOLD': 20, 'DEMOTE': 20, 'ESCALATE': 20}))
    if Counter((str(row['decision']['action']) for row in gold)) != expected_action_support:
        fail(f'{study_kind}: gold action support changed')
    seen_member_ids: set[str] = set()
    factor_ids: set[str] = set()
    for pair in pairs:
        ids = [str(value) for value in pair.get('member_ids', [])]
        if len(ids) != 2 or len(set(ids)) != 2 or set(ids) - set(item_by_id):
            fail(f'{study_kind}: pair membership changed')
        if seen_member_ids & set(ids):
            fail(f'{study_kind}: an item appears in multiple pairs')
        seen_member_ids.update(ids)
        factor_ids.add(str(pair.get('factor_id')))
        left = item_by_id[ids[0]]['model_visible']
        right = item_by_id[ids[1]]['model_visible']
        paths = changed_paths(left, right)
        if specification['controlled_path'] == 'active_profile':
            if paths != ['/active_policy_profile']:
                fail(f'{study_kind}: a pair changes more than the active policy profile')
        elif len(paths) != 1 or not paths[0].startswith('/evidence/0/observed/'):
            fail(f'{study_kind}: a pair changes more than one verifier field')
        pair_actions = {str(gold_by_id[item_id]['decision']['action']) for item_id in ids}
        if len(pair_actions) != 2 or (specification.get('pair_requires_allow', True) and 'ALLOW' not in pair_actions):
            fail(f'{study_kind}: pair actions no longer define an action-changing contrast')
    if len(pairs) != 60 or seen_member_ids != set(item_by_id) or len(factor_ids) != int(specification.get('factor_count', 12)):
        fail(f'{study_kind}: pair or factor coverage changed')
    if specification['controlled_path'] == 'active_profile' and Counter((str(row['model_visible']['active_policy_profile']) for row in items)) != Counter({'POLICY_BLUE': 60, 'POLICY_AMBER': 60}):
        fail(f'{study_kind}: policy-profile support changed')
    if specification.get('transition_graph') is True:
        transition_counts = Counter((str(pair.get('blue_to_amber_transition')) for pair in pairs))
        expected_transitions = {'ALLOW->HOLD', 'ALLOW->DEMOTE', 'ALLOW->ESCALATE', 'HOLD->ALLOW', 'HOLD->ESCALATE', 'DEMOTE->ALLOW', 'DEMOTE->ESCALATE', 'ESCALATE->ALLOW', 'ESCALATE->HOLD', 'ESCALATE->DEMOTE'}
        profile_support: dict[str, Counter[str]] = {'POLICY_BLUE': Counter(), 'POLICY_AMBER': Counter()}
        for item_id, item in item_by_id.items():
            profile = str(item['model_visible']['active_policy_profile'])
            profile_support[profile][str(gold_by_id[item_id]['decision']['action'])] += 1
        coverage = load_json(root / 'transition-coverage.json')
        if not isinstance(coverage, dict):
            fail(f'{study_kind}: transition-coverage receipt is malformed')
        validate_self_digest(coverage, 'self_digest', f'{study_kind} transition coverage')
        expected_bindings = {'manifest_sha256': sha256_file(dataset / 'manifest.json'), 'evaluation_items_sha256': sha256_file(dataset / 'evaluation-items.jsonl'), 'evaluation_gold_sha256': sha256_file(dataset / 'evaluation-gold.jsonl'), 'evaluation_pairs_sha256': sha256_file(dataset / 'evaluation-pairs.json'), 'base_policy_sha256': sha256_file(root / 'base-policy-contract.json'), 'switch_policy_sha256': sha256_file(root / 'policy-contract.json')}
        expected_profile_support = Counter({'ALLOW': 18, 'HOLD': 12, 'DEMOTE': 12, 'ESCALATE': 18})
        if transition_counts != Counter({transition: 6 for transition in expected_transitions}) or coverage.get('status') != 'POLICY_TRANSITION_GRAPH_COVERAGE_COMPLETE' or coverage.get('directed_nonself_action_transitions_possible') != 12 or (coverage.get('directed_action_transitions_semantically_reachable') != 10) or (coverage.get('directed_action_transitions_covered') != 10) or (coverage.get('structurally_unreachable_transitions') != ['HOLD->DEMOTE', 'DEMOTE->HOLD']) or (coverage.get('authored_profile_difference_rules_covered') != 12) or (coverage.get('authored_profile_difference_rules_total') != 12) or (coverage.get('source_bindings') != expected_bindings) or any((value != expected_profile_support for value in profile_support.values())) or ({profile: Counter(actions) for profile, actions in coverage.get('profile_action_support', {}).items()} != profile_support):
            fail(f'{study_kind}: reachable transition-graph coverage changed')
        decision = load_json(root / 'design-decision-receipt.json')
        if not isinstance(decision, dict):
            fail(f'{study_kind}: design-decision receipt is malformed')
        validate_self_digest(decision, 'self_digest', f'{study_kind} design decision')
        if decision.get('status') != 'PREINFERENCE_POLICY_TRANSITION_GRAPH_DESIGN_DECISION' or decision.get('outcomes_used_to_choose_edges_or_contexts') is not False or decision.get('transition_graph_model_calls_before_freeze') != 0 or (decision.get('evaluation_gold_used_to_train_comparators') is not False) or (decision.get('dataset_manifest_sha256') != sha256_file(dataset / 'manifest.json')) or (decision.get('transition_coverage_sha256') != sha256_file(root / 'transition-coverage.json')) or (decision.get('baseline_report_sha256') != sha256_file(root / 'baseline' / 'report.json')) or (decision.get('baseline_prediction_sha256') != {name: sha256_file(root / 'baseline' / name) for name in ('policy_aware-predictions.jsonl', 'profile_blind-predictions.jsonl')}):
            fail(f'{study_kind}: preinference transition-graph decision changed')
    packet_rows = packet.get('records')
    if not isinstance(packet_rows, list) or {str(row.get('item_id')) for row in packet_rows} != set(item_by_id):
        fail(f'{study_kind}: prompt-packet coverage changed')
    packet_payload = {key: value for key, value in packet.items() if key != 'packet_sha256'}
    if packet.get('packet_sha256') != sha256_text(canonical_json(packet_payload)) or dataset_manifest.get('packet_sha256') != packet.get('packet_sha256') or dataset_manifest.get('packet_file_sha256') != sha256_file(dataset / 'evaluation-prompt-packet.json'):
        fail(f'{study_kind}: anonymous prompt-packet binding changed')
    for row in packet_rows:
        prompt = str(row.get('prompt'))
        if row.get('prompt_sha256') != sha256_text(prompt) or row.get('utf8_bytes') != len(prompt.encode('utf-8')) or 'anonymous.invalid/repository' not in prompt:
            fail(f"{study_kind}: anonymous prompt projection changed: {row.get('item_id')}")
    lane_files = manifest.get('lane_files')
    expected_lanes = {str(row['lane_id']) for row in plan.get('formal_lanes', [])}
    if not isinstance(lane_files, dict) or set(lane_files) != expected_lanes or len(expected_lanes) != 2:
        fail(f'{study_kind}: lane manifest changed')
    cells = schedule.get('cells')
    projection = plan.get('anonymous_projection')
    if plan.get('status') != specification['plan_status'] or plan.get('execution', {}).get('client_retry_count') != 0 or plan.get('execution', {}).get('schedule_sha256') != schedule.get('schedule_sha256') or (not isinstance(projection, dict)) or (projection.get('scientific_prompt_content_changed') is not False) or (projection.get('schema_identifier_redacted') is not True) or (projection.get('source_request_body_digests_included') is not False) or (projection.get('redacted_prompts') != 120) or (not isinstance(cells, list)) or (len(cells) != 240) or (len({str(cell['cell_id']) for cell in cells}) != 240):
        fail(f'{study_kind}: frozen execution boundary changed')
    replacement_version = specification.get('replacement_version')
    if replacement_version is not None and (plan.get('replacement_version') != replacement_version or plan.get('freeze', {}).get('prior_ineligible_application_invocations') != 1 or plan.get('freeze', {}).get('prior_durable_terminal_records') != 0 or (plan.get('freeze', {}).get('prior_retained_model_outputs') != 0) or (plan.get('freeze', {}).get('eligible_replacement_inference_calls_before_freeze') != 0)):
        fail(f'{study_kind}: replacement-v2 exclusion boundary changed')
    validate_self_digest(schedule, 'schedule_sha256', f'{study_kind} schedule')
    packet_hashes = {str(row['item_id']): str(row['prompt_sha256']) for row in packet_rows}
    projected_requests: dict[str, str] = {}
    for cell in cells:
        lane_id = str(cell.get('lane_id'))
        item_id = str(cell.get('item_id'))
        expected_request = sha256_text(canonical_json({'anonymous_projection_version': '1.0.0-review', 'item_id': item_id, 'lane_id': lane_id, 'prompt_sha256': packet_hashes.get(item_id)}))
        if cell.get('prompt_sha256') != packet_hashes.get(item_id) or cell.get('request_body_sha256') != expected_request or cell.get('request_digest_scope') != 'ANONYMOUS_LANE_ITEM_PROMPT_PROJECTION':
            fail(f'{study_kind}: anonymous request projection changed: {lane_id}/{item_id}')
        projected_requests[f'{lane_id}\x00{item_id}'] = expected_request
    if receipt.get('status') != 'COMPLETE_ALL_FROZEN_CELLS_TERMINAL' or receipt.get('planned_cells') != 240 or receipt.get('durable_request_intents') != 240 or (receipt.get('durable_terminal_records') != 240) or (receipt.get('application_posts_per_cell') != 1) or (receipt.get('client_retry_count') != 0) or (receipt.get('partial_resume_used') is not False) or (receipt.get('credentials_retained') is not False) or (receipt.get('provider_response_identifiers_retained') is not False) or (receipt.get('hidden_reasoning_blocks_retained') is not False) or (receipt.get('source_journal_digests_included') is not False) or (receipt.get('schedule_sha256') != schedule.get('schedule_sha256')):
        fail(f'{study_kind}: execution receipt changed')
    if replacement_version is not None and (receipt.get('replacement_version') != replacement_version or receipt.get('prior_ineligible_application_invocations') != 1 or receipt.get('void_attempt_receipt_sha256') != sha256_file(root.parent / 'initial-void-exclusion.json')):
        fail(f'{study_kind}: replacement execution boundary changed')
    aggregate_lanes = {str(row.get('lane_id')): row for row in aggregate.get('lanes', []) if isinstance(row, dict)}
    aggregate_freeze = aggregate.get('freeze')
    if aggregate.get('status') != 'COMPLETE' or aggregate.get('design') != specification['aggregate_design'] or set(aggregate_lanes) != expected_lanes or (not isinstance(aggregate_freeze, dict)) or (aggregate_freeze.get('plan_sha256') != sha256_file(root / 'study-plan.json')) or (aggregate_freeze.get('schedule_sha256') != schedule.get('schedule_sha256')) or (aggregate_freeze.get('dataset_manifest_sha256') != sha256_file(dataset / 'manifest.json')) or (aggregate_freeze.get('packet_sha256') != packet.get('packet_sha256')) or (aggregate_freeze.get('execution_receipt_sha256') != sha256_file(root / 'execution-receipt.json')) or (aggregate.get('deterministic_policy_executor', {}).get('label') != 'DEFINITIONAL_POLICY_CEILING_NOT_A_LEARNED_BASELINE'):
        fail(f'{study_kind}: aggregate interpretation boundary changed')
    if replacement_version is not None and aggregate_freeze.get('void_attempt_receipt_sha256') != sha256_file(root.parent / 'initial-void-exclusion.json'):
        fail(f'{study_kind}: aggregate void-attempt binding changed')
    lane_metrics: Json = {}
    for lane_id in sorted(expected_lanes):
        run_path = root / str(lane_files[lane_id])
        rows = load_jsonl(run_path)
        if len(rows) != 120 or {str(row.get('item_id')) for row in rows} != set(item_by_id) or {str(row.get('lane_id')) for row in rows} != {lane_id}:
            fail(f'{study_kind}: run coverage changed for {lane_id}')
        validate_raw_response_hashes(rows, f'{study_kind} {lane_id}')
        validate_prompt_binding(rows, dataset / 'evaluation-prompt-packet.json', f'{study_kind} {lane_id}')
        for row in rows:
            validate_with_schema(row, ROOT / 'v2' / 'schemas' / str(specification['run_schema']), str(row.get('item_id')))
            reject_hidden_reasoning(row, f'{study_kind} {lane_id}')
            if row.get('provider_response_id') is not None or row.get('raw_response_text') is not None or row.get('raw_response_sha256') is not None or (row.get('parse_error_detail') is not None) or (row.get('transport_error') is not None) or (row.get('frozen_plan_commit') != '0000000000000000000000000000000000000010') or (row.get('packet_sha256') != packet.get('packet_sha256')) or (row.get('dataset_manifest_sha256') != sha256_file(dataset / 'manifest.json')) or (row.get('request_sha256') != projected_requests[f"{lane_id}\x00{row.get('item_id')}"]):
                fail(f'{study_kind}: private response or provenance fields survived')
        metrics = derive_balanced_metrics(gold, pairs, rows)
        if not equivalent_json(metrics, aggregate_lanes[lane_id].get('metrics')):
            fail(f'{study_kind}: aggregate differs from item-level records for {lane_id}')
        if aggregate_lanes[lane_id].get('run_sha256') != sha256_file(run_path):
            fail(f'{study_kind}: aggregate run digest changed for {lane_id}')
        if receipt.get('lane_output_sha256', {}).get(run_path.name) != sha256_file(run_path):
            fail(f'{study_kind}: execution receipt run digest changed for {lane_id}')
        lane_metrics[lane_id] = metrics
    baseline_report = load_json(root / 'baseline' / 'report.json')
    if not isinstance(baseline_report, dict) or baseline_report.get('evaluation_gold_loaded') is not False or baseline_report.get('model_outputs_loaded') is not False:
        fail(f'{study_kind}: baseline data-access boundary changed')
    baseline_key = str(specification['aggregate_baseline_key'])
    aggregate_baselines = aggregate.get(baseline_key)
    baseline_files = specification['baseline_files']
    if not isinstance(baseline_files, dict):
        fail(f'{study_kind}: internal baseline specification is malformed')
    if baseline_key == 'structured_random_forest_action_baseline':
        aggregate_baselines = {'structured': aggregate_baselines}
    if not isinstance(aggregate_baselines, dict) or set(aggregate_baselines) != set(baseline_files):
        fail(f'{study_kind}: aggregate baseline set changed')
    baseline_metrics: Json = {}
    for comparator_id, filename in baseline_files.items():
        predictions = load_jsonl(root / 'baseline' / str(filename))
        metrics = derive_balanced_metrics(gold, pairs, baseline_records(predictions))
        entry = aggregate_baselines[comparator_id]
        if not isinstance(entry, dict) or not equivalent_json(metrics, entry.get('metrics')):
            fail(f'{study_kind}: baseline aggregate changed for {comparator_id}')
        baseline_metrics[comparator_id] = metrics
    if specification['controlled_path'] == 'active_profile':
        aware = baseline_metrics['policy_aware']
        blind = baseline_metrics['profile_blind']
        expected_correct = specification.get('baseline_correct', {'policy_aware': {'items': 120, 'pairs': 60}, 'profile_blind': {'items': 60, 'pairs': 0}})
        if aware.get('correct_items') != expected_correct['policy_aware']['items'] or aware.get('correct_pairs') != expected_correct['policy_aware']['pairs'] or blind.get('correct_items') != expected_correct['profile_blind']['items'] or (blind.get('correct_pairs') != expected_correct['profile_blind']['pairs']):
            fail(f'{study_kind}: registered shortcut comparator result changed')
    failure = load_json(root / 'failure-taxonomy.json')
    privacy = load_json(root / 'privacy-receipt-review.json')
    result_receipt = load_json(root / 'result-receipt-review.json')
    if not all((isinstance(value, dict) for value in (failure, privacy, result_receipt))):
        fail(f'{study_kind}: review receipt chain is malformed')
    validate_self_digest(failure, 'self_digest', f'{study_kind} failure taxonomy')
    validate_self_digest(privacy, 'self_digest', f'{study_kind} privacy receipt')
    validate_self_digest(result_receipt, 'self_digest', f'{study_kind} result receipt')
    failure_lanes = failure.get('lanes')
    if failure.get('status') != 'COMPLETE_FROZEN_FAILURE_TAXONOMY' or failure.get('free_form_error_text_included') is not False or (not isinstance(failure_lanes, dict)) or (set(failure_lanes) != expected_lanes):
        fail(f'{study_kind}: failure taxonomy boundary changed')
    for lane_id, metrics in lane_metrics.items():
        lane_failure = failure_lanes[lane_id]
        if lane_failure.get('terminal_records') != 120 or lane_failure.get('parse_status_counts') != metrics.get('parse_status_counts') or sum(lane_failure.get('transport_failure_categories', {}).values()) != metrics.get('parse_status_counts', {}).get('TRANSPORT_ERROR', 0):
            fail(f'{study_kind}: failure taxonomy counts changed for {lane_id}')
    expected_review_files = {'execution-receipt.json': sha256_file(root / 'execution-receipt.json'), 'failure-taxonomy.json': sha256_file(root / 'failure-taxonomy.json'), 'reported-aggregate.json': sha256_file(root / 'reported-aggregate.json'), **{str(relative): sha256_file(root / str(relative)) for relative in lane_files.values()}}
    if privacy.get('status') != 'ANONYMOUS_SYNTHETIC_POLICY_DERIVATIVE_VALIDATED' or privacy.get('terminal_records_validated') != 240 or privacy.get('credentials_included') is not False or (privacy.get('provider_response_identifiers_included') is not False) or (privacy.get('hidden_reasoning_fields_included') is not False) or (privacy.get('raw_final_response_text_included') is not False) or (privacy.get('free_form_error_text_included') is not False) or (privacy.get('all_scheduled_terminal_failures_included') is not True) or (privacy.get('review_file_sha256') != dict(sorted(expected_review_files.items()))):
        fail(f'{study_kind}: privacy receipt boundary changed')
    expected_result_hashes = {'plan_sha256': sha256_file(root / 'study-plan.json'), 'schedule_sha256': sha256_file(root / 'request-schedule.json'), 'dataset_manifest_sha256': sha256_file(dataset / 'manifest.json'), 'baseline_report_sha256': sha256_file(root / 'baseline' / 'report.json'), 'execution_receipt_sha256': sha256_file(root / 'execution-receipt.json'), 'aggregate_sha256': sha256_file(root / 'reported-aggregate.json'), 'failure_taxonomy_sha256': sha256_file(root / 'failure-taxonomy.json'), 'privacy_receipt_sha256': sha256_file(root / 'privacy-receipt-review.json')}
    if result_receipt.get('status') != 'ANONYMOUS_SYNTHETIC_POLICY_RESULTS_SEALED' or result_receipt.get('planned_and_terminal_cells') != 240 or result_receipt.get('application_posts_per_cell') != 1 or (result_receipt.get('client_retry_count') != 0) or (result_receipt.get('all_failures_retained_in_end_to_end_denominator') is not True) or any((result_receipt.get(key) != value for key, value in expected_result_hashes.items())) or (result_receipt.get('run_sha256') != {Path(str(relative)).name: sha256_file(root / str(relative)) for relative in lane_files.values()}):
        fail(f'{study_kind}: result receipt chain changed')
    return {'study_kind': study_kind, 'items_per_lane': 120, 'pairs_per_lane': 60, 'terminal_records': 240, 'lane_metrics': lane_metrics, 'baseline_metrics': baseline_metrics}

def validate_slsa_portability() -> Json:
    return validate_synthetic_policy_evidence('SLSA_DERIVED_POLICY_PORTABILITY')

def validate_local_model_replications() -> Json:
    root = EVIDENCE / 'local-model-replications'
    manifest = load_json(root / 'MANIFEST.json')
    catalog = load_json(root / 'model-catalog.json')
    snapshot = load_json(root / 'model-snapshot-receipt.json')
    qualification = load_json(root / 'environment-qualification.json')
    void_receipt = load_json(root / 'initial-void-exclusion.json')
    if not all((isinstance(value, dict) for value in (manifest, catalog, snapshot, qualification, void_receipt))):
        fail('local-model replication metadata is malformed')
    manifest_payload = deepcopy(manifest)
    observed_manifest_sha = manifest_payload.pop('manifest_sha256', None)
    actual_files = {path.relative_to(root).as_posix(): sha256_file(path) for path in sorted(root.rglob('*')) if path.is_file() and path != root / 'MANIFEST.json'}
    if observed_manifest_sha != sha256_text(canonical_json(manifest_payload)) or manifest.get('status') != 'ANONYMOUS_LOCAL_MODEL_REPLICATIONS' or manifest.get('file_count') != len(actual_files) or (manifest.get('files') != actual_files) or (manifest.get('studies') != ['policy-switch', 'policy-transition-graph', 'slsa']) or (manifest.get('model_weights_included') is not False) or (manifest.get('exact_model_revisions_included') is not True) or (manifest.get('snapshot_file_digests_included') is not True) or (manifest.get('raw_generation_text_included') is not False) or (manifest.get('hidden_reasoning_included') is not False) or (manifest.get('credentials_included') is not False) or (manifest.get('initial_void_attempt_excluded_in_full') is not True):
        fail('local-model replication manifest changed')
    lanes = catalog.get('lanes')
    if catalog.get('status') != 'PREINFERENCE_LOCAL_MODEL_CATALOG' or not isinstance(lanes, list) or len(lanes) != 2 or (len({str(row.get('model_family')) for row in lanes}) != 2) or any((not re.fullmatch('[0-9a-f]{40}', str(row.get('model_revision'))) for row in lanes)) or (catalog.get('selection_boundary', {}).get('models_selected_before_any_benchmark_inference') is not True) or (catalog.get('selection_boundary', {}).get('benchmark_accuracy_or_labels_consulted') is not False):
        fail('local-model pre-inference catalog changed')
    validate_self_digest(snapshot, 'self_digest', 'local-model snapshot receipt')
    validate_self_digest(qualification, 'self_digest', 'local-model qualification receipt')
    validate_self_digest(void_receipt, 'self_digest', 'local-model void-attempt receipt')
    catalog_hash = sha256_file(root / 'model-catalog.json')
    if snapshot.get('status') != 'PINNED_LOCAL_MODEL_SNAPSHOTS_VALIDATED' or snapshot.get('catalog_sha256') != catalog_hash or qualification.get('status') != 'LOCAL_MODEL_ENVIRONMENT_QUALIFIED_BEFORE_BENCHMARK_INFERENCE' or (qualification.get('catalog_sha256') != catalog_hash) or (qualification.get('snapshot_receipt_self_digest') != snapshot.get('self_digest')) or (qualification.get('benchmark_inference_calls') != 0) or (qualification.get('credentials_used_or_retained') is not False):
        fail('local-model environment qualification changed')
    if void_receipt.get('status') != 'INELIGIBLE_LOCAL_ATTEMPT_PRE_TERMINAL_SCHEMA_REJECTION' or void_receipt.get('observed_counts', {}).get('application_invocations') != 1 or void_receipt.get('observed_counts', {}).get('durable_terminal_records') != 0 or (void_receipt.get('observed_counts', {}).get('retained_model_outputs') != 0) or (void_receipt.get('source_bindings_included') is not False) or (void_receipt.get('raw_generation_text_included') is not False) or (void_receipt.get('model_outcome_included') is not False):
        fail('local-model initial void-attempt boundary changed')
    snapshots = snapshot.get('snapshots')
    qualified_models = qualification.get('models')
    if not isinstance(snapshots, list) or not isinstance(qualified_models, list) or len(snapshots) != 2 or (len(qualified_models) != 2) or any((row.get('load_and_generation_succeeded') is not True for row in qualified_models)) or any((row.get('stream_generation_api_succeeded') is not True for row in qualified_models)):
        fail('local-model snapshot or smoke-test coverage changed')
    catalog_models = {(str(row['model_repo']), str(row['model_revision'])) for row in lanes}
    if {(str(row.get('model_repo')), str(row.get('model_revision'))) for row in snapshots} != catalog_models or {(str(row.get('model_repo')), str(row.get('model_revision'))) for row in qualified_models} != catalog_models:
        fail('local-model metadata model sets differ')
    for row in snapshots:
        payload = {key: child for key, child in row.items() if key != 'snapshot_digest'}
        if row.get('snapshot_digest') != sha256_text(canonical_json(payload)) or not isinstance(row.get('files'), list) or row.get('file_count') != len(row['files']):
            fail(f"local-model snapshot tree changed: {row.get('model_repo')}")
    slsa = validate_synthetic_policy_evidence('LOCAL_MODEL_SLSA_POLICY_REPLICATION')
    policy_switch = validate_synthetic_policy_evidence('LOCAL_MODEL_POLICY_SWITCH_REPLICATION')
    transition_graph = validate_synthetic_policy_evidence('LOCAL_MODEL_POLICY_TRANSITION_GRAPH_REPLICATION')
    mutation_audit_path = root / 'policy-transition-graph' / 'mutation-audit.json'
    mutation_audit = load_json(mutation_audit_path)
    if not isinstance(mutation_audit, dict):
        fail('policy-migration mutation audit is malformed')
    validate_self_digest(mutation_audit, 'self_digest', 'policy-migration mutation audit')
    rule_mutants = mutation_audit.get('suites', {}).get('rule_stratified', {})
    graph_mutants = mutation_audit.get('suites', {}).get('transition_graph', {})
    expected_mutation_bindings = {'rule_pairs_sha256': sha256_file(root / 'policy-switch' / 'dataset' / 'evaluation-pairs.json'), 'rule_coverage_sha256': sha256_file(root / 'policy-switch' / 'policy-difference-coverage.json'), 'graph_pairs_sha256': sha256_file(root / 'policy-transition-graph' / 'dataset' / 'evaluation-pairs.json'), 'graph_coverage_sha256': sha256_file(root / 'policy-transition-graph' / 'transition-coverage.json')}
    if mutation_audit.get('status') != 'EDGE_LOCAL_MIGRATION_MUTATION_AUDIT_COMPLETE' or mutation_audit.get('model_or_client_calls') != 0 or mutation_audit.get('mutant_family', {}).get('name') != 'SINGLE_EDGE_STALE_POLICY' or (mutation_audit.get('source_bindings') != expected_mutation_bindings) or (rule_mutants.get('changed_rule_coverage') != {'numerator': 12, 'denominator': 12}) or (rule_mutants.get('edge_local_mutant_detection') != {'numerator': 6, 'denominator': 10, 'value': 0.6}) or (rule_mutants.get('edge_local_mutants_missed') != ['DEMOTE->ESCALATE', 'ESCALATE->DEMOTE', 'ESCALATE->HOLD', 'HOLD->ESCALATE']) or (graph_mutants.get('changed_rule_coverage') != {'numerator': 12, 'denominator': 12}) or (graph_mutants.get('edge_local_mutant_detection') != {'numerator': 10, 'denominator': 10, 'value': 1.0}) or (graph_mutants.get('edge_local_mutants_missed') != []):
        fail('policy-migration mutation audit changed')
    minimal_suite = load_json(root / 'policy-transition-graph' / 'minimal-release-suite.json')
    if not isinstance(minimal_suite, dict):
        fail('minimum policy-migration suite is malformed')
    validate_self_digest(minimal_suite, 'self_digest', 'minimum policy-migration suite')
    if minimal_suite.get('status') != 'PROVABLY_MINIMUM_GRAPH_AND_RULE_COMPLETE_SUITE' or minimal_suite.get('model_or_client_calls_to_derive') != 0 or minimal_suite.get('source_bindings') != {'evaluation_pairs_sha256': sha256_file(root / 'policy-transition-graph' / 'dataset' / 'evaluation-pairs.json'), 'transition_coverage_sha256': sha256_file(root / 'policy-transition-graph' / 'transition-coverage.json')} or (minimal_suite.get('optimality_certificate') != {'lower_bound_pairs': 10, 'lower_bound_reason': 'Each controlled pair realizes exactly one directed action edge, so covering ten distinct reachable edges requires at least ten pairs.', 'witness_pairs': 10, 'bound_met': True}) or (minimal_suite.get('coverage') != {'reachable_edges': {'covered': 10, 'total': 10}, 'changed_rules': {'covered': 12, 'total': 12}}) or (minimal_suite.get('execution_budget') != {'minimum_smoke_pairs': 10, 'minimum_smoke_items': 20, 'balanced_diagnostic_pairs': 60, 'balanced_diagnostic_items': 120, 'item_call_reduction_fraction': 5 / 6}) or (len(minimal_suite.get('selected_pair_ids', [])) != 10) or (len(minimal_suite.get('selected_item_ids', [])) != 20):
        fail('minimum policy-migration suite changed')
    minimum_analysis = load_json(root / 'policy-transition-graph' / 'minimum-subset-analysis.json')
    if not isinstance(minimum_analysis, dict):
        fail('minimum policy-migration subset analysis is malformed')
    validate_self_digest(minimum_analysis, 'self_digest', 'minimum policy-migration subset analysis')
    graph_root = root / 'policy-transition-graph'
    graph_manifest = load_json(graph_root / 'MANIFEST.json')
    graph_plan = load_json(graph_root / 'study-plan.json')
    graph_gold = load_jsonl(graph_root / 'dataset' / 'evaluation-gold.jsonl')
    graph_pairs = load_json(graph_root / 'dataset' / 'evaluation-pairs.json')
    if not isinstance(graph_manifest, dict) or not isinstance(graph_plan, dict) or (not isinstance(graph_pairs, list)):
        fail('minimum policy-migration subset sources are malformed')
    selected_item_ids = minimum_analysis.get('selection', {}).get('selected_item_ids')
    selected_pair_ids = minimum_analysis.get('selection', {}).get('selected_pair_ids')
    if not isinstance(selected_item_ids, list) or not isinstance(selected_pair_ids, list):
        fail('minimum policy-migration subset selection is malformed')
    selected_items = set((str(value) for value in selected_item_ids))
    selected_pairs = set((str(value) for value in selected_pair_ids))
    subset_gold = [row for row in graph_gold if str(row['id']) in selected_items]
    subset_pairs = [row for row in graph_pairs if str(row['pair_id']) in selected_pairs]
    expected_minimum_bindings = {'minimum_suite_sha256': sha256_file(graph_root / 'minimal-release-suite.json'), 'execution_receipt_sha256': sha256_file(graph_root / 'execution-receipt.json'), 'evaluation_gold_sha256': sha256_file(graph_root / 'dataset' / 'evaluation-gold.jsonl'), 'evaluation_pairs_sha256': sha256_file(graph_root / 'dataset' / 'evaluation-pairs.json')}
    expected_provenance = {'analysis_plan_frozen_before_route_execution': True, 'full_graph_terminal_records_before_analysis_freeze': 0, 'minimum_suite_derived_before_route_execution': True, 'model_outputs_consulted': False, 'additional_model_or_client_calls': 0}
    expected_scope = {'additional_model_or_client_calls': 0, 'reuses_full_transition_graph_terminal_records': True, 'independent_model_sample': False, 'natural_input_distribution_claimed': False, 'deployment_reliability_claimed': False, 'replaces_balanced_diagnostic_suite': False}
    if minimum_analysis.get('status') != 'COMPLETE_PROSPECTIVE_MINIMUM_MIGRATION_SUBSET_ANALYSIS' or minimum_analysis.get('truth_status') != 'COMPUTATIONAL' or minimum_analysis.get('source_identity') != 'WITHHELD_DURING_DOUBLE_BLIND_REVIEW' or (minimum_analysis.get('provenance') != expected_provenance) or (minimum_analysis.get('source_bindings') != expected_minimum_bindings) or (selected_item_ids != minimal_suite.get('selected_item_ids')) or (selected_pair_ids != minimal_suite.get('selected_pair_ids')) or (len(subset_gold) != 20) or (len(subset_pairs) != 10) or (minimum_analysis.get('selection', {}).get('pairs') != 10) or (minimum_analysis.get('selection', {}).get('items') != 20) or (minimum_analysis.get('selection', {}).get('changed_rules_covered') != 12) or (minimum_analysis.get('selection', {}).get('reachable_edges_covered') != 10) or (minimum_analysis.get('selection', {}).get('selected_before_route_execution') is not True) or (minimum_analysis.get('selection', {}).get('model_outputs_consulted') is not False) or (minimum_analysis.get('gate') != {'pass_rule': 'ALL_20_ITEMS_VALID_AND_CORRECT_AND_ALL_10_PAIRS_CORRECT', 'failure_rule': 'EVERY_SERVICE_SYNTAX_SCHEMA_OR_SEMANTIC_FAILURE_IS_INCORRECT'}) or (minimum_analysis.get('scope') != expected_scope):
        fail('minimum policy-migration subset analysis boundary changed')
    graph_lane_files = graph_manifest.get('lane_files')
    graph_analysis_lanes = minimum_analysis.get('lanes')
    graph_model_families = {str(row['lane_id']): str(row['model_family']) for row in graph_plan.get('formal_lanes', [])}
    if not isinstance(graph_lane_files, dict) or not isinstance(graph_analysis_lanes, list) or {str(row.get('lane_id')) for row in graph_analysis_lanes} != set(graph_lane_files):
        fail('minimum policy-migration subset lane set changed')
    minimum_lane_metrics: Json = {}
    for lane in graph_analysis_lanes:
        lane_id = str(lane['lane_id'])
        run_path = graph_root / str(graph_lane_files[lane_id])
        subset_records = [row for row in load_jsonl(run_path) if str(row['item_id']) in selected_items]
        metrics = derive_balanced_metrics(subset_gold, subset_pairs, subset_records)
        strict_pass = metrics.get('items') == 20 and metrics.get('pairs') == 10 and (metrics.get('parseable_items') == 20) and (metrics.get('correct_items') == 20) and (metrics.get('covered_pairs') == 10) and (metrics.get('correct_pairs') == 10)
        if len(subset_records) != 20 or lane.get('model_family') != graph_model_families.get(lane_id) or lane.get('run_sha256') != sha256_file(run_path) or (not equivalent_json(lane.get('metrics'), metrics)) or (lane.get('strict_gate_pass') is not strict_pass):
            fail(f'minimum policy-migration subset metrics changed: {lane_id}')
        minimum_lane_metrics[lane_id] = metrics
    expected_bindings = {'catalog_sha256': catalog_hash, 'requirements_sha256': sha256_file(root / 'requirements.txt'), 'snapshot_receipt_sha256': sha256_file(root / 'model-snapshot-receipt.json'), 'snapshot_receipt_self_digest': snapshot['self_digest'], 'qualification_receipt_sha256': sha256_file(root / 'environment-qualification.json'), 'qualification_receipt_self_digest': qualification['self_digest'], 'void_attempt_receipt_sha256': sha256_file(root / 'initial-void-exclusion.json'), 'void_attempt_receipt_self_digest': void_receipt['self_digest']}
    for dataset_key in ('slsa', 'policy-switch', 'policy-transition-graph'):
        plan = load_json(root / dataset_key / 'study-plan.json')
        if not isinstance(plan, dict) or any((plan.get('freeze', {}).get(key) != value for key, value in expected_bindings.items())):
            fail(f'local-model plan environment binding changed: {dataset_key}')
        planned_models = {(str(row.get('model')), str(row.get('model_revision'))) for row in plan.get('formal_lanes', [])}
        if planned_models != catalog_models:
            fail(f'local-model plan model set changed: {dataset_key}')
    return {'studies': 3, 'models': len(catalog_models), 'terminal_records': 720, 'slsa': slsa, 'policy_switch': policy_switch, 'policy_transition_graph': transition_graph, 'policy_migration_edge_mutants': {'rule_stratified': '6/10', 'transition_graph': '10/10'}, 'minimum_policy_migration_smoke_suite': {'pairs': 10, 'items': 20, 'changed_rules': '12/12', 'reachable_edges': '10/10', 'lane_metrics': minimum_lane_metrics}}

def validate_hosted_exclusion_receipts() -> Json:
    paths = {'initial_policy_switch': EVIDENCE / 'hosted-policy-switch-exclusion.json', 'policy_switch_replacement': EVIDENCE / 'hosted-policy-switch-replacement-exclusion.json', 'policy_transition_graph': EVIDENCE / 'hosted-policy-transition-graph-exclusion.json', 'minimum_policy_migration': EVIDENCE / 'hosted-minimum-policy-migration-exclusion.json'}
    receipts = {name: load_json(path) for name, path in paths.items()}
    if any((not isinstance(receipt, dict) for receipt in receipts.values())):
        fail('hosted exclusion receipt is malformed')
    for name, receipt in receipts.items():
        validate_self_digest(receipt, 'self_digest', f'hosted exclusion {name}')
        if receipt.get('source_identity') != 'WITHHELD_DURING_DOUBLE_BLIND_REVIEW' or receipt.get('source_bindings_included') is not False or receipt.get('raw_terminal_records_included') is not False or (receipt.get('valid_output_subset_included') is not False) or (receipt.get('new_model_calls_performed_for_receipt') != 0):
            fail(f'hosted exclusion privacy or selection boundary changed: {name}')
    initial = receipts['initial_policy_switch']
    if initial.get('status') != 'HOSTED_POLICY_SWITCH_EXCLUDED_IN_FULL_SHARED_QUOTA_EXHAUSTION' or initial.get('decision', {}).get('hosted_model_rows_enter_manuscript') is not False or initial.get('decision', {}).get('successful_row_subset_selected') is not False:
        fail('initial hosted policy-switch exclusion changed')
    expected_status = {'policy_switch_replacement': 'HOSTED_REPLACEMENT_EXCLUDED_IN_FULL_PERSISTENT_SHARED_RESOURCE_EXHAUSTION', 'policy_transition_graph': 'HOSTED_TRANSITION_GRAPH_EXCLUDED_IN_FULL_PERSISTENT_SHARED_RESOURCE_EXHAUSTION'}
    for name in ('policy_switch_replacement', 'policy_transition_graph'):
        receipt = receipts[name]
        classification = receipt.get('classification', {})
        decision = receipt.get('decision', {})
        if receipt.get('status') != expected_status[name] or receipt.get('free_form_error_text_included') is not False or classification.get('eligible_for_model_efficacy_reporting') is not False or (classification.get('explicit_resource_exhaustion_errors') != 240) or (classification.get('persistent_exhaustion_trigger_sequence') != 0) or (classification.get('transport_status_counts') != {'ERROR': 240}) or (classification.get('parse_status_counts') != {'TRANSPORT_ERROR': 240}) or (decision.get('all_240_terminal_outcomes_considered') is not True) or (decision.get('hosted_model_rows_enter_manuscript') is not False) or (decision.get('conditional_success_subset_selected') is not False):
            fail(f'complete hosted exclusion changed: {name}')
    graph = receipts['policy_transition_graph']
    if graph.get('study_scope') != 'REACHABLE_POLICY_TRANSITION_GRAPH' or graph.get('model_configuration_labels_included') is not False:
        fail('hosted transition-graph exclusion scope changed')
    minimum = receipts['minimum_policy_migration']
    minimum_classification = minimum.get('classification', {})
    minimum_decision = minimum.get('decision', {})
    if minimum.get('status') != 'HOSTED_MINIMUM_SUITE_EXCLUDED_IN_FULL_PERSISTENT_SHARED_RESOURCE_EXHAUSTION' or minimum.get('study_scope') != 'MINIMUM_GRAPH_AND_RULE_COMPLETE_POLICY_MIGRATION_GATE' or minimum.get('selected_pairs') != 10 or (minimum.get('selected_items') != 20) or (minimum.get('planned_route_cells') != 40) or (minimum.get('free_form_error_text_included') is not False) or (minimum.get('model_configuration_labels_included') is not False) or (minimum_classification.get('eligible_for_route_conformance_reporting') is not False) or (minimum_classification.get('explicit_resource_exhaustion_errors') != 40) or (minimum_classification.get('persistent_exhaustion_trigger_sequence') != 0) or (minimum_classification.get('transport_status_counts') != {'ERROR': 40}) or (minimum_classification.get('parse_status_counts') != {'TRANSPORT_ERROR': 40}) or (minimum_decision.get('all_40_terminal_outcomes_considered') is not True) or (minimum_decision.get('hosted_route_rows_enter_manuscript') is not False) or (minimum_decision.get('conditional_success_subset_selected') is not False):
        fail('hosted minimum policy-migration exclusion changed')
    return {'status': 'HOSTED_EXCLUSION_RECEIPTS_PASS', 'receipt_count': len(receipts), 'raw_terminal_records_included': False, 'model_rows_included': False, 'successful_subsets_selected': False}

def main() -> int:
    result = {
        "status": "PASS",
        "fresh_confirmatory": validate_fresh_confirmatory(),
        "balanced_public_challenge": validate_balanced_public_challenge(),
        "slsa_portability": validate_slsa_portability(),
        "local_model_replications": validate_local_model_replications(),
        "hosted_exclusions": validate_hosted_exclusion_receipts(),
    }
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
