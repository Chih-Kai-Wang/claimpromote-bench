#!/usr/bin/env python3
"""Recompute the two paper-facing studies from anonymous item-level records."""
from __future__ import annotations
import hashlib
import json
import math
import re
from collections import Counter
from copy import deepcopy
from pathlib import Path
from typing import Any, NoReturn
from analyze_balanced_public_challenge import derive_reporting_metrics as derive_balanced_metrics
from analyze_confirmatory_hidden_study import analyze as analyze_fresh_confirmatory
from claimpromotebench.dataset import validate_with_schema
from claimpromotebench.hashing import canonical_json
ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence'
Json = dict[str, Any]
ACTIONS = ('ALLOW', 'HOLD', 'DEMOTE', 'ESCALATE')

def fail(message: str) -> NoReturn:
    raise SystemExit(f'anonymous-empirical-evidence: {message}')

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))

def load_jsonl(path: Path) -> list[Json]:
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
    if any((not isinstance(row, dict) for row in rows)):
        fail(f'non-object JSONL record: {path.relative_to(ROOT)}')
    return rows

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return 'sha256:' + digest.hexdigest()

def sha256_text(value: str) -> str:
    return 'sha256:' + hashlib.sha256(value.encode('utf-8')).hexdigest()

def equivalent_json(left: Any, right: Any) -> bool:
    """Compare recomputed JSON while tolerating only machine-scale float summation drift."""
    if isinstance(left, bool) or isinstance(right, bool):
        return left is right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isclose(float(left), float(right), rel_tol=1e-12, abs_tol=1e-12)
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all((equivalent_json(left[key], right[key]) for key in left))
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all((equivalent_json(left_value, right_value) for left_value, right_value in zip(left, right, strict=True)))
    return bool(left == right)

def validate_raw_response_hashes(rows: list[Json], label: str) -> None:
    for row in rows:
        raw = row.get('raw_response_text')
        observed = row.get('raw_response_sha256')
        if raw is None:
            if observed is not None:
                fail(f'{label}: null raw response has a digest')
        elif observed != sha256_text(str(raw)):
            fail(f"{label}: raw response digest mismatch for {row.get('item_id')}")

def validate_prompt_binding(rows: list[Json], packet_path: Path, label: str) -> None:
    packet = load_json(packet_path)
    if not isinstance(packet, dict) or not isinstance(packet.get('records'), list):
        fail(f'{label}: malformed prompt packet')
    prompts = {str(row['item_id']): str(row['prompt_sha256']) for row in packet['records']}
    for row in rows:
        item_id = str(row.get('item_id'))
        if item_id not in prompts or row.get('prompt_sha256') != prompts[item_id]:
            fail(f'{label}: prompt binding mismatch for {item_id}')

def reject_hidden_reasoning(value: Any, label: str) -> None:
    if isinstance(value, dict):
        forbidden = {'reasoning_content', 'thinking', 'thinking_content', 'thought', 'thoughts'}
        overlap = forbidden & set(value)
        if overlap:
            fail(f'{label}: hidden reasoning fields survived: {sorted(overlap)}')
        if str(value.get('type', '')).lower() in {'reasoning', 'thinking'}:
            fail(f'{label}: hidden reasoning content block survived')
        for child in value.values():
            reject_hidden_reasoning(child, label)
    elif isinstance(value, list):
        for child in value:
            reject_hidden_reasoning(child, label)

def _fresh_scientific_projection(value: Json) -> Json:
    projected = deepcopy(value)
    projected.pop('aggregate_sha256', None)
    projected.pop('source_identity', None)
    scores = projected.get('scores')
    if isinstance(scores, dict):
        for score in scores.values():
            if isinstance(score, dict):
                score.pop('run_sha256', None)
    return projected

def validate_fresh_confirmatory() -> Json:
    root = EVIDENCE / 'fresh-confirmatory'
    manifest_path = root / 'MANIFEST.json'
    manifest = load_json(manifest_path)
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict):
        fail('fresh confirmatory evidence manifest is malformed')
    manifest_payload = deepcopy(manifest)
    observed_manifest_sha = manifest_payload.pop('manifest_sha256', None)
    if observed_manifest_sha != sha256_text(canonical_json(manifest_payload)):
        fail('fresh confirmatory evidence manifest self-digest changed')
    actual_files = {path.relative_to(root).as_posix(): sha256_file(path) for path in sorted(root.rglob('*')) if path.is_file() and path != manifest_path}
    if manifest['files'] != actual_files or manifest.get('file_count') != len(actual_files):
        fail('fresh confirmatory evidence manifest coverage changed')
    dataset = root / 'dataset'
    dataset_manifest = load_json(dataset / 'manifest.json')
    if not isinstance(dataset_manifest, dict) or not isinstance(dataset_manifest.get('files'), dict):
        fail('fresh confirmatory dataset manifest is malformed')
    for relative, expected in dataset_manifest['files'].items():
        path = dataset / relative
        if not path.is_file() or sha256_file(path) != expected:
            fail(f'fresh confirmatory dataset file digest changed: {relative}')
    inputs = load_jsonl(dataset / 'inputs.jsonl')
    gold = load_jsonl(dataset / 'gold.jsonl')
    pairs = load_json(dataset / 'pairs.json')
    if not isinstance(pairs, list):
        fail('fresh confirmatory pair file is malformed')
    input_ids = {str(row['id']) for row in inputs}
    gold_ids = {str(row['id']) for row in gold}
    pair_ids = {str(row['pair_id']) for row in pairs}
    if len(input_ids) != 300 or input_ids != gold_ids or len(pair_ids) != 150:
        fail('fresh confirmatory dataset coverage changed')
    if any((not re.fullmatch('v1-test-cfo-\\d{3}-[ab]', item_id) for item_id in input_ids)):
        fail('fresh confirmatory item namespace differs from released cfo IDs')
    if any((not re.fullmatch('v1-test-cfo-\\d{3}', pair_id) for pair_id in pair_ids)):
        fail('fresh confirmatory pair namespace differs from released cfo IDs')
    correction = load_json(root / 'frozen-manifest-metadata-correction.json')
    if not isinstance(correction, dict):
        fail('fresh confirmatory frozen-manifest correction is malformed')
    correction_payload = deepcopy(correction)
    observed_correction_sha = correction_payload.pop('self_digest', None)
    if observed_correction_sha != sha256_text(canonical_json(correction_payload)):
        fail('fresh confirmatory frozen-manifest correction self-digest changed')
    if correction.get('source_manifest_sha256') != sha256_file(dataset / 'manifest.json') or correction.get('coverage_check', {}).get('item_ids_matching_observed_pattern') != 300 or correction.get('coverage_check', {}).get('pair_ids_matching_observed_pattern') != 150 or (correction.get('scientific_impact') != 'NONE'):
        fail('fresh confirmatory frozen-manifest correction does not match the dataset')
    c2 = load_json(root / 'c2-receipt-review.json')
    if not isinstance(c2, dict) or (c2.get('analysis_executed_before_receipt') is not False or c2.get('gold_loaded_before_receipt') is not False or c2.get('contains_gold_labels') is not False or (c2.get('planned_cells') != 600) or (c2.get('sealed_cells') != 600) or (c2.get('outcome_counts') != {'RESPONSE_RECORDED': 600})):
        fail('fresh confirmatory anonymous C2 receipt changed')
    expected_lanes = {'opencode-go-deepseek-v4-flash-matched', 'opencode-go-qwen3.7-max'}
    lane_files = manifest.get('lane_files')
    if not isinstance(lane_files, dict) or set(lane_files) != expected_lanes:
        fail('fresh confirmatory lane manifest changed')
    rows_by_lane: dict[str, list[Json]] = {}
    run_paths: list[Path] = []
    for lane_id, relative in sorted(lane_files.items()):
        path = root / str(relative)
        rows = load_jsonl(path)
        run_paths.append(path)
        if len(rows) != 300 or {str(row.get('lane_id')) for row in rows} != {lane_id} or {str(row.get('item_id')) for row in rows} != input_ids:
            fail(f'fresh confirmatory projected run coverage changed: {lane_id}')
        for row in rows:
            reject_hidden_reasoning(row, f'fresh confirmatory {lane_id}')
            if row.get('application_post_count') != 1 or row.get('client_retry_count') != 0:
                fail(f'fresh confirmatory request accounting changed: {lane_id}')
            if row.get('redirect_followed') is not False:
                fail(f'fresh confirmatory redirect boundary changed: {lane_id}')
            raw_text = row.get('raw_final_text')
            raw_sha = row.get('raw_final_text_sha256')
            if raw_text is None:
                if raw_sha is not None:
                    fail(f'fresh confirmatory null final text has a digest: {lane_id}')
            elif raw_sha != sha256_text(str(raw_text)):
                fail(f'fresh confirmatory final-text digest changed: {lane_id}')
        rows_by_lane[lane_id] = rows
    qwen_id = 'opencode-go-qwen3.7-max'
    flash_id = 'opencode-go-deepseek-v4-flash-matched'
    qwen = rows_by_lane[qwen_id]
    flash = rows_by_lane[flash_id]
    if Counter((str(row.get('parse_status')) for row in qwen)) != Counter({'OK': 272, 'HTTP_ERROR': 15, 'TRANSPORT_ERROR': 10, 'SEMANTIC_ERROR': 3}):
        fail('fresh confirmatory Qwen parser-status distribution changed')
    if Counter((row.get('http_status') for row in qwen)) != Counter({200: 275, 500: 14, 503: 1, None: 10}):
        fail('fresh confirmatory Qwen HTTP-status distribution changed')
    if Counter((str(row.get('parse_status')) for row in flash)) != Counter({'HTTP_ERROR': 300}):
        fail('fresh confirmatory Flash parser-status distribution changed')
    if Counter((row.get('http_status') for row in flash)) != Counter({401: 300}):
        fail('fresh confirmatory Flash HTTP-status distribution changed')
    qwen_usage = [row['usage'] for row in qwen if isinstance(row.get('usage'), dict) and isinstance(row['usage'].get('input_tokens'), int)]
    if len(qwen_usage) != 275 or sum((int(row.get('input_tokens', 0)) for row in qwen_usage)) != 662053 or sum((int(row.get('output_tokens', 0)) for row in qwen_usage)) != 613618 or (sum((int(row.get('output_tokens', 0)) > 1536 for row in qwen_usage)) != 261):
        fail('fresh confirmatory Qwen provider-reported usage changed')
    plan = load_json(root / 'study-plan.json')
    packet = load_json(root / 'prompt-packet.json')
    baselines = load_json(root / 'baselines.json')
    reported = load_json(root / 'reported-analysis.json')
    if not all((isinstance(value, dict) for value in (plan, packet, baselines, reported))):
        fail('fresh confirmatory plan, packet, baseline, or analysis is malformed')
    recomputed = analyze_fresh_confirmatory(dataset, packet, plan, baselines, run_paths)
    if not equivalent_json(_fresh_scientific_projection(recomputed), _fresh_scientific_projection(reported)):
        fail('fresh confirmatory reported science differs from projected C2 records')
    study_result = load_json(root / 'study-result.json')
    reporting_addendum = load_json(root / 'reporting-addendum.json')
    redaction = load_json(root / 'redaction-receipt-review.json')
    if not all((isinstance(value, dict) for value in (study_result, reporting_addendum, redaction))):
        fail('fresh confirmatory study result, reporting addendum, or redaction receipt is malformed')
    addendum_payload = deepcopy(reporting_addendum)
    observed_addendum_sha = addendum_payload.pop('self_digest', None)
    if observed_addendum_sha != sha256_text(canonical_json(addendum_payload)):
        fail('fresh confirmatory reporting addendum self-digest changed')
    qwen_score = recomputed['scores'][qwen_id]['raw']
    qwen_test = next((row for row in recomputed['confirmatory_item_correctness_tests']['tests'] if row['model_lane'] == qwen_id))
    qwen_summary = study_result.get('qwen_service_configuration', {})
    flash_summary = study_result.get('deepseek_flash_service_configuration', {})
    gold_actions = {str(row['id']): str(row['decision']['action']) for row in gold}
    qwen_predictions = {str(row['item_id']): str(row['raw_decision']['action']) if row.get('parse_status') == 'OK' and isinstance(row.get('raw_decision'), dict) else None for row in qwen}
    complete_pairs = [pair for pair in pairs if all((qwen_predictions[str(item_id)] in ACTIONS for item_id in pair['member_ids']))]
    correct_pairs = [pair for pair in pairs if all((qwen_predictions[str(item_id)] == gold_actions[str(item_id)] for item_id in pair['member_ids']))]
    factor_support: dict[str, Counter[str]] = {action: Counter() for action in ACTIONS}
    factor_counts: dict[str, Json] = {}
    for pair in pairs:
        factor_id = str(pair['factor_id'])
        invalid_action = gold_actions[str(pair['invalid_id'])]
        factor_support[invalid_action][factor_id] += 1
        factor = factor_counts.setdefault(factor_id, {'factor_id': factor_id, 'family': str(pair['family']), 'invalid_action': invalid_action, 'pairs': 0, 'covered_pairs': 0, 'correct_pairs': 0})
        member_ids = [str(item_id) for item_id in pair['member_ids']]
        factor['pairs'] += 1
        factor['covered_pairs'] += int(all((qwen_predictions[item_id] in ACTIONS for item_id in member_ids)))
        factor['correct_pairs'] += int(all((qwen_predictions[item_id] == gold_actions[item_id] for item_id in member_ids)))
    factor_metrics: list[Json] = []
    for factor_id in sorted(factor_counts):
        factor = factor_counts[factor_id]
        covered = int(factor['covered_pairs'])
        pair_count = int(factor['pairs'])
        pair_correct = int(factor['correct_pairs'])
        factor_metrics.append({**factor, 'pair_coverage': covered / pair_count, 'end_to_end_pair_accuracy': pair_correct / pair_count, 'conditional_pair_accuracy': pair_correct / covered if covered else None})
    qwen_addendum = reporting_addendum.get('qwen_service_configuration', {})
    policy_ceiling = reporting_addendum.get('deterministic_policy_executor', {})
    if not equivalent_json(qwen_summary.get('end_to_end_item_accuracy'), qwen_score['item_accuracy']) or not equivalent_json(qwen_summary.get('end_to_end_pair_accuracy'), qwen_score['pair_accuracy']) or (not equivalent_json(qwen_summary.get('decision_coverage'), qwen_score['decision_coverage'])) or (qwen_score['per_action']['DEMOTE']['correct'] != 0) or (not equivalent_json(qwen_summary.get('superiority_test_vs_public_dev_text_nb', {}).get('holm_adjusted_p'), qwen_test['holm_adjusted_p'])) or (flash_summary.get('model_capability_interpretation') != 'NON_EVALUABLE_NO_MODEL_OUTPUT') or (flash_summary.get('http_401_records') != 300) or (qwen_addendum.get('valid_decisions') != 272) or (qwen_addendum.get('correct_items') != 258) or (qwen_addendum.get('complete_pairs') != len(complete_pairs)) or (len(complete_pairs) != 123) or (qwen_addendum.get('correct_pairs') != len(correct_pairs)) or (len(correct_pairs) != 113) or (not equivalent_json(qwen_addendum.get('conditional_item_accuracy_given_valid_decision'), 258 / 272)) or (not equivalent_json(qwen_addendum.get('conditional_pair_accuracy_given_complete_pair'), 113 / 123)) or (qwen_addendum.get('confusion') != qwen_score['confusion']) or (qwen_addendum.get('factor_metrics') != factor_metrics) or (reporting_addendum.get('invalid_action_factor_support') != {action: dict(sorted(counts.items())) for action, counts in factor_support.items() if counts}) or (policy_ceiling.get('role') != 'DEFINITIONAL_POLICY_CEILING_NOT_A_LEARNED_EMPIRICAL_BASELINE') or (policy_ceiling.get('correct_items') != 300) or (policy_ceiling.get('correct_pairs') != 150):
        fail('fresh confirmatory compact study result or reporting addendum differs from recomputation')
    if redaction.get('hidden_reasoning_present_in_public_release') is not False or redaction.get('original_scored_artifacts_modified') is not False or redaction.get('post_c2_transform') is not True or (redaction.get('public_provider_envelopes_allowlisted') is not True) or (redaction.get('redacted_unique_model_item_cells') != 275) or (redaction.get('removed_content_blocks_including_raw_and_c2_copies') != 550) or (redaction.get('scientific_analysis_payload_byte_identical') is not True) or (redaction.get('source_to_derived_row_hashes_verified_before_anonymization') is not True):
        fail('fresh confirmatory anonymous redaction receipt changed')
    return {'c2_sealed_cells': c2['sealed_cells'], 'flash_http_401_records': 300, 'flash_model_efficacy': 'NON_EVALUABLE', 'qwen_decision_coverage': qwen_score['decision_coverage'], 'qwen_demote_correct': qwen_score['per_action']['DEMOTE']['correct'], 'qwen_item_accuracy': qwen_score['item_accuracy'], 'qwen_conditional_item_accuracy': qwen_addendum['conditional_item_accuracy_given_valid_decision'], 'qwen_pair_coverage': qwen_addendum['pair_coverage'], 'qwen_pair_accuracy': qwen_score['pair_accuracy'], 'qwen_factor_count': len(factor_metrics), 'qwen_conditional_pair_accuracy': qwen_addendum['conditional_pair_accuracy_given_complete_pair'], 'qwen_vs_public_dev_nb_holm_p': qwen_test['holm_adjusted_p'], 'redaction_status': redaction['status']}

def validate_balanced_public_challenge() -> Json:
    root = EVIDENCE / 'balanced-public-challenge'
    manifest = load_json(root / 'MANIFEST.json')
    if not isinstance(manifest, dict) or not isinstance(manifest.get('files'), dict):
        fail('balanced challenge manifest is malformed')
    manifest_payload = deepcopy(manifest)
    observed_manifest_sha = manifest_payload.pop('manifest_sha256', None)
    if observed_manifest_sha != sha256_text(canonical_json(manifest_payload)):
        fail('balanced challenge manifest self-digest changed')
    declared = manifest['files']
    actual = {path.relative_to(root).as_posix(): sha256_file(path) for path in sorted(root.rglob('*')) if path.is_file() and path.name != 'MANIFEST.json'}
    if manifest.get('file_count') != len(actual) or declared != actual:
        fail('balanced challenge manifest differs from the generated tree')
    scope = manifest.get('scope', {})
    if scope.get('hidden_reasoning_included') is not False or scope.get('provider_response_identifiers_included') is not False or scope.get('source_artifact_or_workflow_ids_included') is not False:
        fail('balanced challenge anonymous scope changed')
    dataset = root / 'dataset'
    inputs = load_jsonl(dataset / 'inputs.jsonl')
    gold = load_jsonl(dataset / 'gold.jsonl')
    pairs = load_json(dataset / 'pairs.json')
    plan = load_json(root / 'study-plan.json')
    packet = load_json(root / 'prompt-packet.json')
    aggregate = load_json(root / 'reported-aggregate.json')
    correction = load_json(root / 'reporting-correction-review.json')
    receipt = load_json(root / 'privacy-receipt-review.json')
    if not all((isinstance(value, dict) for value in (plan, packet, aggregate, correction, receipt))):
        fail('balanced challenge plan, packet, aggregate, correction, or receipt is malformed')
    if not isinstance(pairs, list):
        fail('balanced challenge pairs are malformed')
    input_ids = {str(row['id']) for row in inputs}
    gold_by_id = {str(row['id']): row for row in gold}
    pair_ids = {str(row['pair_id']) for row in pairs}
    factor_ids = {str(row['factor_id']) for row in pairs}
    if len(input_ids) != 180 or input_ids != set(gold_by_id) or len(pair_ids) != 90 or (len(factor_ids) != 15):
        fail('balanced challenge dataset coverage changed')
    action_counts = Counter((str(row['decision']['action']) for row in gold))
    if action_counts != Counter({'ALLOW': 90, 'HOLD': 30, 'DEMOTE': 30, 'ESCALATE': 30}):
        fail('balanced challenge gold action distribution changed')
    if plan.get('status') != 'FROZEN_BEFORE_SCORED_INFERENCE' or plan.get('design', {}).get('attempts_per_item') != 1 or plan.get('design', {}).get('held_out_generalization_claim') is not False or (plan.get('statistics', {}).get('failure_rule') != 'Every non-OK response remains in the denominator as incorrect.'):
        fail('balanced challenge plan boundary changed')
    packet_rows = packet.get('records')
    if not isinstance(packet_rows, list) or {str(row.get('item_id')) for row in packet_rows} != input_ids:
        fail('balanced challenge prompt-packet coverage changed')
    lane_files = manifest.get('lane_files')
    analysis_files = manifest.get('analysis_files')
    expected_lanes = {'opencode-go-deepseek-v4-flash-matched', 'opencode-go-qwen3.7-max'}
    if not isinstance(lane_files, dict) or not isinstance(analysis_files, dict) or set(lane_files) != expected_lanes or (set(analysis_files) != expected_lanes):
        fail('balanced challenge lane manifest changed')
    aggregate_lanes = {str(row.get('lane_id')): row for row in aggregate.get('lanes', []) if isinstance(row, dict)}
    if set(aggregate_lanes) != expected_lanes:
        fail('balanced challenge aggregate lane set changed')
    lane_metrics: dict[str, Json] = {}
    for lane_id in sorted(expected_lanes):
        run_path = root / str(lane_files[lane_id])
        rows = load_jsonl(run_path)
        if len(rows) != 180 or {str(row.get('item_id')) for row in rows} != input_ids or {str(row.get('lane_id')) for row in rows} != {lane_id}:
            fail(f'balanced challenge run coverage changed: {lane_id}')
        validate_raw_response_hashes(rows, f'balanced challenge {lane_id}')
        validate_prompt_binding(rows, root / 'prompt-packet.json', f'balanced challenge {lane_id}')
        for row in rows:
            item_id = str(row.get('item_id'))
            validate_with_schema(row, ROOT / 'v2' / 'schemas' / 'stronger-model-run-record.schema.json', item_id)
            reject_hidden_reasoning(row, f'balanced challenge {lane_id}')
            if row.get('provider_response_id') is not None:
                fail(f'balanced challenge retained a provider response ID: {item_id}')
        metrics = derive_balanced_metrics(gold, pairs, rows)
        if not equivalent_json(metrics, aggregate_lanes[lane_id].get('metrics')):
            fail(f'balanced challenge aggregate differs from item-level records: {lane_id}')
        if aggregate_lanes[lane_id].get('run_sha256') != sha256_file(run_path):
            fail(f'balanced challenge aggregate run digest changed: {lane_id}')
        analysis_path = root / str(analysis_files[lane_id])
        analysis = load_json(analysis_path)
        if not isinstance(analysis, dict) or analysis.get('lane_id') != lane_id or analysis.get('run_sha256') != sha256_file(run_path):
            fail(f'balanced challenge lane analysis binding changed: {lane_id}')
        lane_metrics[lane_id] = metrics
    qwen = lane_metrics['opencode-go-qwen3.7-max']
    flash = lane_metrics['opencode-go-deepseek-v4-flash-matched']
    if correction.get('status') != 'REPORTING_CORRECTION' or correction.get('source_identity') != 'WITHHELD_DURING_DOUBLE_BLIND_REVIEW' or correction.get('metric_convention') != 'FIXED_FOUR_CLASS_MACRO_F1_WITH_ZERO_DIVISION_EQUAL_TO_ZERO' or (correction.get('scope', {}).get('model_calls_performed') != 0) or (correction.get('scope', {}).get('raw_or_terminal_records_changed') is not False) or (correction.get('scope', {}).get('primary_endpoints_changed') is not False) or (correction.get('anonymous_run_sha256') != {lane_id: sha256_file(root / str(lane_files[lane_id])) for lane_id in sorted(expected_lanes)}):
        fail('balanced challenge reporting-correction boundary changed')
    affected = correction.get('affected_lanes', {}).get('opencode-go-deepseek-v4-flash-matched', {})
    if affected.get('historical') != {'conditional_macro_f1': 0.6243032962151766, 'macro_f1': 0.5236761371215153, 'per_action.DEMOTE.conditional_f1': None, 'per_action.DEMOTE.end_to_end_f1': None, 'per_action.DEMOTE.precision': None} or affected.get('corrected') != {'conditional_macro_f1': flash['conditional_macro_f1'], 'macro_f1': flash['macro_f1'], 'per_action.DEMOTE.conditional_f1': flash['per_action']['DEMOTE']['conditional_f1'], 'per_action.DEMOTE.end_to_end_f1': flash['per_action']['DEMOTE']['end_to_end_f1'], 'per_action.DEMOTE.precision': flash['per_action']['DEMOTE']['precision']}:
        fail('balanced challenge reporting-correction values changed')
    expected_qwen = {'parseable_items': 148, 'correct_items': 132, 'covered_pairs': 64, 'correct_pairs': 48, 'end_to_end_item_accuracy': 0.7333333333333333, 'conditional_item_accuracy': 0.8918918918918919, 'end_to_end_pair_accuracy': 0.5333333333333333, 'conditional_pair_accuracy': 0.75}
    expected_flash = {'parseable_items': 146, 'correct_items': 90, 'covered_pairs': 61, 'correct_pairs': 13, 'end_to_end_item_accuracy': 0.5, 'conditional_item_accuracy': 0.6164383561643836, 'end_to_end_pair_accuracy': 0.14444444444444443, 'conditional_pair_accuracy': 0.21311475409836064, 'macro_f1': 0.39275710284113646, 'conditional_macro_f1': 0.46822747216138244}
    for label, observed, expected in (('Qwen', qwen, expected_qwen), ('Flash', flash, expected_flash)):
        for key, value in expected.items():
            if not equivalent_json(observed.get(key), value):
                fail(f'balanced challenge {label} metric changed: {key}')
    validation = receipt.get('validation', {})
    if receipt.get('source_artifact_or_workflow_ids_included') is not False or validation.get('terminal_records_validated') != 360 or validation.get('provider_account_identifier_findings') != 0 or (validation.get('retained_provider_response_ids') != 0) or (validation.get('hidden_reasoning_field_findings') != 0):
        fail('balanced challenge privacy receipt changed')
    if aggregate.get('design') != 'PUBLIC_PRECOMMITTED_BALANCED_CHALLENGE' or aggregate.get('service_comparison', {}).get('causal_model_ablation_claimed') is not False or aggregate.get('deterministic_policy_executor', {}).get('label') != 'DEFINITIONAL_POLICY_CEILING_NOT_A_LEARNED_EMPIRICAL_BASELINE':
        fail('balanced challenge interpretation boundary changed')
    return {'items_per_lane': 180, 'pairs_per_lane': 90, 'qwen_valid_decisions': qwen['parseable_items'], 'qwen_end_to_end_item_accuracy': qwen['end_to_end_item_accuracy'], 'qwen_end_to_end_pair_accuracy': qwen['end_to_end_pair_accuracy'], 'flash_valid_decisions': flash['parseable_items'], 'flash_end_to_end_item_accuracy': flash['end_to_end_item_accuracy'], 'flash_end_to_end_pair_accuracy': flash['end_to_end_pair_accuracy'], 'privacy_status': receipt['status']}

def main() -> int:
    result = {
        "status": "PASS",
        "fresh_confirmatory": validate_fresh_confirmatory(),
        "balanced_public_challenge": validate_balanced_public_challenge(),
    }
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
