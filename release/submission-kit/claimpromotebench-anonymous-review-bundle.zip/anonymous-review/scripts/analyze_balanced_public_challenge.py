#!/usr/bin/env python3
"""Minimal balanced-challenge metrics used by the anonymous reviewer replay."""
from __future__ import annotations
from collections import Counter
from typing import Any, NoReturn
Json = dict[str, Any]
ACTIONS = ('ALLOW', 'HOLD', 'DEMOTE', 'ESCALATE')
PREDICTION_COLUMNS = (*ACTIONS, 'NO_VALID_DECISION')

def fail(message: str) -> NoReturn:
    raise SystemExit(f'balanced-public-challenge-analysis: {message}')

def _rate(numerator: int, denominator: int) -> float | None:
    return numerator / denominator if denominator else None

def _zero_division_rate(numerator: int, denominator: int) -> float:
    """Return a fixed-class classification rate with zero division defined as zero."""
    return numerator / denominator if denominator else 0.0

def _f1(precision: float, recall: float) -> float:
    if precision + recall == 0:
        return 0.0
    return 2.0 * precision * recall / (precision + recall)

def _class_metrics(confusion: Json) -> Json:
    per_action: Json = {}
    for action in ACTIONS:
        gold_total = sum((int(confusion[action][column]) for column in PREDICTION_COLUMNS))
        parseable_gold = gold_total - int(confusion[action]['NO_VALID_DECISION'])
        predicted_total = sum((int(confusion[gold][action]) for gold in ACTIONS))
        correct = int(confusion[action][action])
        precision = _zero_division_rate(correct, predicted_total)
        end_to_end_recall = _zero_division_rate(correct, gold_total)
        conditional_recall = _zero_division_rate(correct, parseable_gold)
        per_action[action] = {'gold_instances': gold_total, 'parseable_gold_instances': parseable_gold, 'predicted_instances': predicted_total, 'correct': correct, 'precision': precision, 'end_to_end_recall': end_to_end_recall, 'conditional_recall': conditional_recall, 'end_to_end_f1': _f1(precision, end_to_end_recall), 'conditional_f1': _f1(precision, conditional_recall)}
    return {'per_action': per_action, 'balanced_action_recall': sum((per_action[action]['end_to_end_recall'] for action in ACTIONS)) / len(ACTIONS), 'conditional_balanced_action_recall': sum((per_action[action]['conditional_recall'] for action in ACTIONS)) / len(ACTIONS), 'macro_f1': sum((per_action[action]['end_to_end_f1'] for action in ACTIONS)) / len(ACTIONS), 'conditional_macro_f1': sum((per_action[action]['conditional_f1'] for action in ACTIONS)) / len(ACTIONS)}

def derive_reporting_metrics(gold: list[Json], pairs: list[Json], records: list[Json]) -> Json:
    """Derive registered item, pair, class, and factor metrics for one lane."""
    gold_by_id = {str(row['id']): row for row in gold}
    record_by_id = {str(row['item_id']): row for row in records}
    if len(record_by_id) != len(records):
        fail('a lane contains duplicate item IDs')
    if set(record_by_id) != set(gold_by_id):
        fail('a lane does not cover exactly the frozen gold IDs')
    confusion: Json = {gold_action: {column: 0 for column in PREDICTION_COLUMNS} for gold_action in ACTIONS}
    parse_status_counts = Counter((str(row['parse_status']) for row in records))
    correct_items = 0
    parseable_items = 0
    for item_id, gold_row in gold_by_id.items():
        row = record_by_id[item_id]
        gold_action = str(gold_row['decision']['action'])
        if gold_action not in ACTIONS:
            fail(f'unknown gold action for {item_id}: {gold_action}')
        if row['parse_status'] == 'OK':
            parseable_items += 1
            prediction = str(row['raw_decision']['action'])
            if prediction not in ACTIONS:
                fail(f'unknown predicted action for {item_id}: {prediction}')
            confusion[gold_action][prediction] += 1
            correct_items += prediction == gold_action
        else:
            confusion[gold_action]['NO_VALID_DECISION'] += 1
    factor_counts: dict[str, Json] = {}
    covered_pairs = 0
    correct_pairs = 0
    for pair in pairs:
        factor_id = str(pair['factor_id'])
        factor = factor_counts.setdefault(factor_id, {'factor_id': factor_id, 'family': pair.get('family'), 'pairs': 0, 'covered_pairs': 0, 'correct_pairs': 0})
        factor['pairs'] += 1
        member_ids = [str(value) for value in pair['member_ids']]
        member_records = [record_by_id[item_id] for item_id in member_ids]
        covered = all((row['parse_status'] == 'OK' for row in member_records))
        if not covered:
            continue
        covered_pairs += 1
        factor['covered_pairs'] += 1
        pair_correct = all((row['raw_decision']['action'] == gold_by_id[item_id]['decision']['action'] for item_id, row in zip(member_ids, member_records, strict=True)))
        correct_pairs += pair_correct
        factor['correct_pairs'] += pair_correct
    factor_metrics: list[Json] = []
    for factor_id in sorted(factor_counts):
        factor = factor_counts[factor_id]
        factor_metrics.append({**factor, 'pair_coverage': _rate(factor['covered_pairs'], factor['pairs']), 'end_to_end_pair_accuracy': _rate(factor['correct_pairs'], factor['pairs']), 'conditional_pair_accuracy': _rate(factor['correct_pairs'], factor['covered_pairs'])})
    class_metrics = _class_metrics(confusion)
    return {'items': len(records), 'parseable_items': parseable_items, 'correct_items': correct_items, 'decision_coverage': _rate(parseable_items, len(records)), 'end_to_end_item_accuracy': _rate(correct_items, len(records)), 'conditional_item_accuracy': _rate(correct_items, parseable_items), 'pairs': len(pairs), 'covered_pairs': covered_pairs, 'correct_pairs': correct_pairs, 'pair_coverage': _rate(covered_pairs, len(pairs)), 'end_to_end_pair_accuracy': _rate(correct_pairs, len(pairs)), 'conditional_pair_accuracy': _rate(correct_pairs, covered_pairs), 'parse_status_counts': dict(sorted(parse_status_counts.items())), 'confusion_matrix': {'row_semantics': 'gold action', 'column_semantics': 'raw model action or absence of a valid decision', 'row_order': list(ACTIONS), 'column_order': list(PREDICTION_COLUMNS), 'counts': confusion}, **class_metrics, 'factor_metrics': factor_metrics, 'failure_rule': 'Every non-OK response remains in the denominator as incorrect.'}
