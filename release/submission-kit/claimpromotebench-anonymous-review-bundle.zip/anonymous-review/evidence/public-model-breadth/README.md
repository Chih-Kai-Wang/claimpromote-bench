# Public model-breadth reviewer evidence

This directory contains a prospectively frozen seven-configuration supplement on the known
180-item balanced public challenge. Each scheduled cell has one terminal outcome and zero
client retries. Every unusable outcome remains incorrect in end-to-end metrics.

The runs retain scoring fields and final-response digests but exclude final-response text,
free-form error detail, provider response identifiers, account identifiers, credentials, and
hidden reasoning. The comparison expands model-family and configuration coverage only; model,
serving implementation, and API adapter are not causally isolated. The shared dataset and prompt
packet are in the sibling `balanced-public-challenge` evidence directory.
