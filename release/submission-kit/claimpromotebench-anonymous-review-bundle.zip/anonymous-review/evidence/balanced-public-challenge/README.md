# Balanced public challenge reviewer evidence

This directory contains the frozen 90-pair / 180-item public challenge, its prompt packet, two
one-pass zero-retry service runs, lane analyses, a corrected reported aggregate, and the bound
reporting-correction receipt. The invalid members are balanced across HOLD, DEMOTE, and ESCALATE
(30 each), with 90 ALLOW members over 15 factors.

Every non-OK response remains incorrect in end-to-end item and pair metrics. The two service
stacks differ, so the lane comparison is descriptive and is not a causal model ablation or a
hidden-test generalization estimate. `privacy-receipt-review.json` records the independent
360-record validation and zero findings for provider account identifiers, retained provider
response IDs, and hidden reasoning. Source workflow, artifact, repository, and commit identities
are withheld during double-blind review.

Run `scripts/validate_anonymous_empirical_evidence.py` from the bundle root to recompute coverage,
conditional and end-to-end accuracy, per-action recall, and the complete confusion matrices.
The correction defines zero-prediction classes as zero for fixed-four-class Macro-F1; it performs
no model calls and changes no primary endpoint, confusion cell, recall, or item-level record.
