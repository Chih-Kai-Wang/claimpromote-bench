# Fresh confirmatory reviewer evidence

This directory is a compact double-blind derivative of the immutable r6 execution. It contains the
released 300-item paired dataset, the frozen prompt packet and baseline predictions, two projected
C2-complete service-configuration runs, the preregistered study plan, and the complete scientific
analysis with only source-identifying provenance hashes removed.

The Qwen service configuration produced 272 valid decisions and achieved 86.00% end-to-end item
accuracy and 75.33% pair accuracy. Among covered outputs it achieved 258/272 item accuracy; 123/150
pairs had two valid decisions and 113/123 of those complete pairs were correct. The Flash lane
returned 300 HTTP 401 responses and no model output; it is an authentication or client-service
configuration failure, not an estimate of model accuracy. The Qwen result includes every failure as
incorrect without retry and has zero DEMOTE recall (0/8). `reporting-addendum.json` exposes the
full confusion matrix, factor-level pair outcomes, action-factor concentration, conditional metrics,
and deterministic policy ceiling.

Provider hidden-thinking blocks are not included. They were removed only in a deterministic
post-C2 publication derivative; the original C2 seal and scores were not altered. `MANIFEST.json`
binds every file in this directory. Recompute the reported analysis with
`scripts/validate_anonymous_empirical_evidence.py` from the bundle root.

The immutable dataset manifest retains one stale non-operative `CFM_R5` namespace label and three
construction-time `PENDING` values. The released IDs are all `v1-test-cfo-*`; the bound correction
overlay explains why the original manifest remains byte-identical and how current states are carried
by later receipts.
