# Pinned open-weight local replications

The two preselected model families were fixed before any benchmark inference. The bundle records
exact model revisions and snapshot file digests but does not redistribute model weights. The SLSA
evidence contrast, rule-stratified policy contrast, and reachable transition graph each contain
two complete 120-item local routes.
An initial schema-incompatible attempt retained one request intent and no terminal model output;
it is excluded in full and represented only by a redacted receipt. The replacement runs add
replayable configuration breadth, not a model-population estimate or causal model comparison.
