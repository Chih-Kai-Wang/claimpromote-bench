# Pinned local-model policy-switch replication reviewer evidence

This derivative contains all 240 zero-retry terminal outcomes for two pinned four-bit MLX snapshots. Raw generations, free-form runtime errors, local paths, provider identifiers, credentials, and hidden reasoning are excluded. Model repositories, exact revisions, snapshot file digests, generation settings, structured decisions, failures, and recomputable metrics remain. Between-route differences are descriptive.
