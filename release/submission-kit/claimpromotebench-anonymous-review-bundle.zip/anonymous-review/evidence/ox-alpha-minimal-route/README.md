# Ox Alpha minimum-route smoke replay

This directory retains all 20 scheduled outcomes from a one-pass, zero-retry replay of the
previously derived ten-pair minimum policy-migration suite. The route was selected after other
results were known, but its route, schedule, failure rule, and strict 20/20-item plus 10/10-pair
gate were committed before the first call. Ox Alpha is a time-stamped stealth route label, not a
model-family identity. The replay is an auxiliary route smoke test, not an independent policy
replication, reliability estimate, provider ranking, or causal ablation.

Each projected row retains the item, pair, parse class, action when valid, and a finite failure
class. Raw response text, full structured decisions, free-form errors, provider identifiers,
credentials, hidden reasoning, private paths, and commit identity are excluded. Every failed cell
remains in the end-to-end denominator.
