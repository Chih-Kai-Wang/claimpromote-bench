# Capable-extension attempt protocol snapshots

These directories preserve the exact request and parser implementation plus the exact plan file
used at each accepted-request stage. They were extracted byte-for-byte from the registered source
commits. Together with `../prompt-packet.json`, the released schemas, raw records, and analyses,
they expose the request construction and parsing rules for every executed pilot attempt.

- `stage-1-initial` is commit `0000000000000000000000000000000000000000`. Run `anonymous-capable-transport-run`
  reached the B.AI pilot; the other lanes stopped before accepted requests because credential
  values contained trailing newlines.
- `stage-2-transport-amended` is commit `0000000000000000000000000000000000000001`.
  Run `anonymous-capable-first-qualified-run` executed all seven pilots with valid credentials. The matched Flash lane
  qualified and completed its fresh full pass.
- `stage-3-final-adapter` is commit `0000000000000000000000000000000000000002`.
  Run `anonymous-capable-final-qualified-run` requalified six lanes after registered adapter changes; the already qualified
  matched Flash lane was not rerun. Qwen3.7-Max qualified and completed its fresh full pass.

The earlier preflight run `anonymous-capable-preflight-run` issued no model request, so it has no response record. The
terminal `canonical` view is an analysis selection, not a claim that each lane ran only once. All
14 executed pilots and both completed full passes are retained under `../attempt-history/`.
