# SLSA-derived portability reviewer evidence

This directory contains the complete 120-item, 60-pair second-policy study. SLSA and in-toto
ground the evidence fields; the transition policy and labels are author-defined. Every scheduled
service or output failure remains in the end-to-end denominator. The incomplete predecessor is
excluded by `void-exclusion-receipt.json`; its raw records are omitted.

Raw response text, free-form provider errors, credentials, provider response IDs, hidden reasoning,
and source repository or commit identity are excluded. Structured decisions, parser classes,
usage, timings, hashes, gold labels, pair membership, and complete failure cells remain.
